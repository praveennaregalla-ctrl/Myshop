import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 3000,
});

export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount || 0);
};

// ==========================================
// Persistent LocalStorage Database Fallback
// ==========================================
const DB_KEYS = {
  PRODUCTS: 'sv_fashion_products_db',
  CUSTOMERS: 'sv_fashion_customers_db',
  SALES: 'sv_fashion_sales_db',
  PAYMENTS: 'sv_fashion_payments_db',
  SETTINGS: 'sv_fashion_settings_db',
};

const INITIAL_PRODUCTS = [
  {
    id: 1,
    name: 'Italian Navy Slim Fit Suit',
    category: 'Formal Wear',
    brand: 'Raymond',
    size: 'L',
    color: 'Navy Blue',
    purchase_price: 4500.0,
    selling_price: 7999.0,
    quantity: 12,
    min_stock_threshold: 5,
    supplier_details: 'Milano Fabrics Ltd, Mumbai',
    image_url: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=500&auto=format&fit=crop&q=60',
    description: 'Crafted with premium Italian wool blend fabric, peak lapel silhouette.',
    is_new_arrival: true
  },
  {
    id: 2,
    name: 'Emerald Silk Evening Gown',
    category: 'Ethnic & Dresses',
    brand: 'Zara',
    size: 'M',
    color: 'Emerald Green',
    purchase_price: 3200.0,
    selling_price: 5499.0,
    quantity: 8,
    min_stock_threshold: 5,
    supplier_details: 'Elegance Couture, Surat',
    image_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&auto=format&fit=crop&q=60',
    description: 'Flowing pure silk evening gown with subtle flare and pleated waist accent.',
    is_new_arrival: true
  },
  {
    id: 3,
    name: 'Crisp Linen Casual Shirt',
    category: 'Casual Shirts',
    brand: 'Allen Solly',
    size: 'L',
    color: 'Pure White',
    purchase_price: 900.0,
    selling_price: 1899.0,
    quantity: 24,
    min_stock_threshold: 6,
    supplier_details: 'Breezy Cotton Mills, Coimbatore',
    image_url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500&auto=format&fit=crop&q=60',
    description: 'Breathable 100% natural linen button-down casual shirt with spread collar.',
    is_new_arrival: true
  },
  {
    id: 4,
    name: 'Vintage Leather Bomber Jacket',
    category: 'Outerwear',
    brand: 'Woodland',
    size: 'XL',
    color: 'Tan Brown',
    purchase_price: 2800.0,
    selling_price: 4999.0,
    quantity: 4,
    min_stock_threshold: 5,
    supplier_details: 'Apex Leather Works, Kanpur',
    image_url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500&auto=format&fit=crop&q=60',
    description: 'Genuine grain leather bomber jacket with ribbed cuffs.',
    is_new_arrival: false
  },
  {
    id: 5,
    name: 'Classic 511 Slim Denim Jeans',
    category: 'Denim & Pants',
    brand: "Levi's",
    size: '32',
    color: 'Indigo Blue',
    purchase_price: 1200.0,
    selling_price: 2499.0,
    quantity: 18,
    min_stock_threshold: 5,
    supplier_details: 'Indigo Denim Corp, Ahmedabad',
    image_url: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=500&auto=format&fit=crop&q=60',
    description: 'Classic stretch denim with authentic washed finish.',
    is_new_arrival: true
  }
];

const INITIAL_CUSTOMERS = [
  {
    id: 1,
    name: 'Rahul Sharma',
    phone: '+91 98450 12345',
    address: '12 Rosewood Apartments, Bangalore',
    opening_balance: 0,
    total_purchase_amount: 7500,
    total_amount_paid: 5000,
    remaining_balance: 2500,
    notes: 'Prefers Formal Wear and Raymond suits'
  },
  {
    id: 2,
    name: 'Priya Patel',
    phone: '+91 97123 45678',
    address: 'Flat 4B Green Valley, Mumbai',
    opening_balance: 0,
    total_purchase_amount: 5499,
    total_amount_paid: 5499,
    remaining_balance: 0,
    notes: 'Frequent festive dresses shopper'
  },
  {
    id: 3,
    name: 'Amit Verma',
    phone: '+91 99234 56789',
    address: '58 Model Town, Delhi',
    opening_balance: 0,
    total_purchase_amount: 4000,
    total_amount_paid: 3000,
    remaining_balance: 1000,
    notes: 'Casuals and jackets enthusiast'
  },
  {
    id: 4,
    name: 'Sneha Reddy',
    phone: '+91 98877 66554',
    address: 'Jubilee Hills, Hyderabad',
    opening_balance: 0,
    total_purchase_amount: 2999,
    total_amount_paid: 1500,
    remaining_balance: 1499,
    notes: 'Wedding party bulk buyer'
  },
  {
    id: 5,
    name: 'Vikram Singh',
    phone: '+91 94140 98765',
    address: 'C-12 Malviya Nagar, Jaipur',
    opening_balance: 0,
    total_purchase_amount: 3000,
    total_amount_paid: 1000,
    remaining_balance: 2000,
    notes: 'Regular denim and shirts client'
  }
];

const INITIAL_SALES = [
  {
    id: 1,
    invoice_number: 'INV-2026-001',
    customer_id: 1,
    customer_name: 'Rahul Sharma',
    customer_phone: '+91 98450 12345',
    subtotal: 7999,
    discount: 499,
    total_amount: 7500,
    amount_paid: 5000,
    remaining_balance: 2500,
    payment_method: 'UPI',
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    notes: 'Italian Navy Suit',
    items: [
      { product_name: 'Italian Navy Slim Fit Suit', size: 'L', color: 'Navy Blue', quantity: 1, unit_price: 7999, total_price: 7999 }
    ]
  },
  {
    id: 2,
    invoice_number: 'INV-2026-002',
    customer_id: 2,
    customer_name: 'Priya Patel',
    customer_phone: '+91 97123 45678',
    subtotal: 5499,
    discount: 0,
    total_amount: 5499,
    amount_paid: 5499,
    remaining_balance: 0,
    payment_method: 'Card',
    created_at: new Date(Date.now() - 86400000).toISOString(),
    notes: 'Emerald Gown',
    items: [
      { product_name: 'Emerald Silk Evening Gown', size: 'M', color: 'Emerald Green', quantity: 1, unit_price: 5499, total_price: 5499 }
    ]
  }
];

const INITIAL_PAYMENTS = [
  {
    id: 1,
    customer_id: 1,
    customer_name: 'Rahul Sharma',
    sale_id: 1,
    amount_paid: 5000,
    payment_method: 'UPI',
    item_description: 'Italian Navy Slim Fit Suit',
    payment_notes: 'Initial billing payment',
    payment_date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0]
  },
  {
    id: 2,
    customer_id: 2,
    customer_name: 'Priya Patel',
    sale_id: 2,
    amount_paid: 5499,
    payment_method: 'Card',
    item_description: 'Emerald Silk Evening Gown',
    payment_notes: 'Full payment received',
    payment_date: new Date(Date.now() - 86400000).toISOString().split('T')[0]
  },
  {
    id: 3,
    customer_id: 3,
    customer_name: 'Amit Verma',
    sale_id: null,
    amount_paid: 500,
    payment_method: 'UPI',
    item_description: 'Pending Balance Collection',
    payment_notes: 'Partial payment',
    payment_date: new Date().toISOString().split('T')[0]
  }
];

function getStored(key, defaultVal) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(defaultVal));
      return defaultVal;
    }
    return JSON.parse(raw);
  } catch {
    return defaultVal;
  }
}

function setStored(key, val) {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.error('LocalStorage write error', e);
  }
}

export const productsAPI = {
  getAll: async (params) => {
    try {
      return await api.get('/products', { params });
    } catch {
      let list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      if (params?.category) list = list.filter(p => p.category === params.category);
      if (params?.search) {
        const s = params.search.toLowerCase();
        list = list.filter(p => p.name.toLowerCase().includes(s) || p.brand.toLowerCase().includes(s));
      }
      return { data: list };
    }
  },
  getNewArrivals: async () => {
    try {
      return await api.get('/products/new-arrivals');
    } catch {
      const list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      return { data: list.filter(p => p.is_new_arrival) };
    }
  },
  getById: async (id) => {
    try {
      return await api.get(`/products/${id}`);
    } catch {
      const list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      const item = list.find(p => p.id === parseInt(id));
      return { data: item };
    }
  },
  create: async (data) => {
    try {
      return await api.post('/products', data);
    } catch {
      const list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      const newProd = { ...data, id: Date.now() };
      list.unshift(newProd);
      setStored(DB_KEYS.PRODUCTS, list);
      return { data: newProd };
    }
  },
  update: async (id, data) => {
    try {
      return await api.put(`/products/${id}`, data);
    } catch {
      const list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      const idx = list.findIndex(p => p.id === parseInt(id));
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...data };
        setStored(DB_KEYS.PRODUCTS, list);
      }
      return { data: list[idx] };
    }
  },
  delete: async (id) => {
    try {
      return await api.delete(`/products/${id}`);
    } catch {
      let list = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      list = list.filter(p => p.id !== parseInt(id));
      setStored(DB_KEYS.PRODUCTS, list);
      return { data: { success: true } };
    }
  },
};

export const customersAPI = {
  getAll: async (params) => {
    try {
      return await api.get('/customers', { params });
    } catch {
      let list = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      if (params?.search) {
        const s = params.search.toLowerCase();
        list = list.filter(c => c.name.toLowerCase().includes(s) || c.phone.includes(s));
      }
      if (params?.has_due === 'true') {
        list = list.filter(c => c.remaining_balance > 0);
      }
      return { data: list };
    }
  },
  getById: async (id) => {
    try {
      return await api.get(`/customers/${id}`);
    } catch {
      const list = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const cust = list.find(c => c.id === parseInt(id));
      const sales = getStored(DB_KEYS.SALES, INITIAL_SALES).filter(s => s.customer_id === parseInt(id));
      return { data: { ...cust, sales } };
    }
  },
  create: async (data) => {
    try {
      return await api.post('/customers', data);
    } catch {
      const list = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const opening = parseFloat(data.opening_balance || 0);
      const newCust = {
        ...data,
        id: Date.now(),
        total_purchase_amount: opening,
        total_amount_paid: 0,
        remaining_balance: opening,
      };
      list.unshift(newCust);
      setStored(DB_KEYS.CUSTOMERS, list);
      return { data: newCust };
    }
  },
  update: async (id, data) => {
    try {
      return await api.put(`/customers/${id}`, data);
    } catch {
      const list = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const idx = list.findIndex(c => c.id === parseInt(id));
      if (idx >= 0) {
        list[idx] = { ...list[idx], ...data };
        setStored(DB_KEYS.CUSTOMERS, list);
      }
      return { data: list[idx] };
    }
  },
  delete: async (id) => {
    try {
      return await api.delete(`/customers/${id}`);
    } catch {
      let list = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      list = list.filter(c => c.id !== parseInt(id));
      setStored(DB_KEYS.CUSTOMERS, list);
      return { data: { success: true } };
    }
  },
};

export const salesAPI = {
  getAll: async (params) => {
    try {
      return await api.get('/sales', { params });
    } catch {
      return { data: getStored(DB_KEYS.SALES, INITIAL_SALES) };
    }
  },
  getById: async (id) => {
    try {
      return await api.get(`/sales/${id}`);
    } catch {
      const list = getStored(DB_KEYS.SALES, INITIAL_SALES);
      return { data: list.find(s => s.id === parseInt(id)) };
    }
  },
  create: async (data) => {
    try {
      return await api.post('/sales', data);
    } catch {
      const sales = getStored(DB_KEYS.SALES, INITIAL_SALES);
      const products = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      const customers = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const payments = getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS);

      const newSaleId = Date.now();
      const invoiceNo = `INV-${newSaleId.toString().slice(-6)}`;
      const subtotal = (data.items || []).reduce((acc, item) => acc + item.total_price, 0);
      const discount = parseFloat(data.discount || 0);
      const totalAmount = subtotal - discount;
      const amountPaid = parseFloat(data.amount_paid || 0);
      const balance = totalAmount - amountPaid;

      // 1. Stock reduction
      for (const it of data.items || []) {
        const p = products.find(prod => prod.id === it.product_id);
        if (p) p.quantity = Math.max(0, p.quantity - it.quantity);
      }
      setStored(DB_KEYS.PRODUCTS, products);

      // 2. Update Customer Balance
      let cust = customers.find(c => c.id === data.customer_id);
      if (cust) {
        cust.total_purchase_amount = (cust.total_purchase_amount || 0) + totalAmount;
        cust.total_amount_paid = (cust.total_amount_paid || 0) + amountPaid;
        cust.remaining_balance = Math.max(0, cust.total_purchase_amount - cust.total_amount_paid);
        setStored(DB_KEYS.CUSTOMERS, customers);
      }

      // 3. Record Payment
      if (amountPaid > 0) {
        payments.unshift({
          id: Date.now() + 1,
          customer_id: cust?.id || null,
          customer_name: cust?.name || 'Walk-in Customer',
          sale_id: newSaleId,
          amount_paid: amountPaid,
          payment_method: data.payment_method || 'Cash',
          item_description: `Sale ${invoiceNo}`,
          payment_notes: 'POS Checkout',
          payment_date: new Date().toISOString().split('T')[0]
        });
        setStored(DB_KEYS.PAYMENTS, payments);
      }

      const newSale = {
        id: newSaleId,
        invoice_number: invoiceNo,
        customer_id: cust?.id || null,
        customer_name: cust?.name || 'Walk-in Customer',
        customer_phone: cust?.phone || '+91 90000 00000',
        subtotal,
        discount,
        total_amount: totalAmount,
        amount_paid: amountPaid,
        remaining_balance: balance,
        payment_method: data.payment_method || 'Cash',
        created_at: new Date().toISOString(),
        items: data.items
      };

      sales.unshift(newSale);
      setStored(DB_KEYS.SALES, sales);
      return { data: newSale };
    }
  },
};

export const paymentsAPI = {
  getAll: async (params) => {
    try {
      return await api.get('/payments', { params });
    } catch {
      return { data: getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS) };
    }
  },
  getByDate: async (dateStr) => {
    try {
      return await api.get(`/payments/date/${dateStr}`);
    } catch {
      const list = getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS);
      const filtered = list.filter(p => p.payment_date === dateStr);
      const daily_total = filtered.reduce((acc, p) => acc + (parseFloat(p.amount_paid) || 0), 0);
      return { data: { payments: filtered, daily_total, count: filtered.length } };
    }
  },
  create: async (data) => {
    try {
      return await api.post('/payments', data);
    } catch {
      const payments = getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS);
      const customers = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);

      const paid = parseFloat(data.amount_paid);
      const newPay = {
        id: Date.now(),
        customer_id: data.customer_id || null,
        customer_name: data.customer_name || 'Customer',
        sale_id: data.sale_id || null,
        amount_paid: paid,
        payment_method: data.payment_method || 'Cash',
        item_description: data.item_description || 'Payment Received',
        payment_notes: data.payment_notes || '',
        payment_date: data.payment_date || new Date().toISOString().split('T')[0]
      };
      payments.unshift(newPay);
      setStored(DB_KEYS.PAYMENTS, payments);

      // Adjust customer balance
      if (data.customer_id) {
        const cust = customers.find(c => c.id === data.customer_id);
        if (cust) {
          cust.total_amount_paid = (cust.total_amount_paid || 0) + paid;
          cust.remaining_balance = Math.max(0, (cust.total_purchase_amount || 0) - cust.total_amount_paid);
          setStored(DB_KEYS.CUSTOMERS, customers);
        }
      }

      return { data: newPay };
    }
  },
};

export const balanceAPI = {
  getAll: async (params) => {
    try {
      return await api.get('/balances', { params });
    } catch {
      const customers = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const sales = getStored(DB_KEYS.SALES, INITIAL_SALES);

      let records = customers.map(c => {
        const custSales = sales.filter(s => s.customer_id === c.id);
        const purchasedItems = [];
        for (const s of custSales) {
          for (const item of s.items || []) {
            purchasedItems.push({
              product_name: item.product_name,
              size: item.size || '-',
              quantity: item.quantity,
              unit_price: item.unit_price,
              total_price: item.total_price,
              invoice_number: s.invoice_number
            });
          }
        }

        return {
          customer_id: c.id,
          customer_name: c.name,
          customer_phone: c.phone,
          customer_address: c.address,
          total_purchase_amount: c.total_purchase_amount || 0,
          total_amount_paid: c.total_amount_paid || 0,
          remaining_balance: c.remaining_balance || 0,
          status: (c.remaining_balance || 0) > 0 ? 'Pending' : 'Fully Paid',
          purchased_items: purchasedItems
        };
      });

      if (params?.status === 'pending') records = records.filter(r => r.remaining_balance > 0);
      if (params?.status === 'paid') records = records.filter(r => r.remaining_balance === 0);
      if (params?.search) {
        const s = params.search.toLowerCase();
        records = records.filter(r => r.customer_name.toLowerCase().includes(s) || r.customer_phone.includes(s));
      }

      const totalPending = records.reduce((acc, r) => acc + r.remaining_balance, 0);
      const pendingCount = records.filter(r => r.remaining_balance > 0).length;

      return {
        data: {
          records,
          total_pending_balance: totalPending,
          pending_customers_count: pendingCount
        }
      };
    }
  },
  addDue: async (data) => {
    try {
      return await api.post('/balances/add-due', data);
    } catch {
      const customers = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const sales = getStored(DB_KEYS.SALES, INITIAL_SALES);
      const dueAmount = parseFloat(data.amount);

      const cust = customers.find(c => c.id === data.customer_id);
      if (cust) {
        cust.total_purchase_amount = (cust.total_purchase_amount || 0) + dueAmount;
        cust.remaining_balance = (cust.remaining_balance || 0) + dueAmount;
        setStored(DB_KEYS.CUSTOMERS, customers);

        const newSale = {
          id: Date.now(),
          invoice_number: `DUE-${Date.now().toString().slice(-6)}`,
          customer_id: cust.id,
          customer_name: cust.name,
          customer_phone: cust.phone,
          subtotal: dueAmount,
          discount: 0,
          total_amount: dueAmount,
          amount_paid: 0,
          remaining_balance: dueAmount,
          payment_method: 'Due Account',
          created_at: new Date().toISOString(),
          items: [
            {
              product_name: data.item_description || 'Credit Cloth Purchase',
              size: '-',
              color: '-',
              quantity: 1,
              unit_price: dueAmount,
              total_price: dueAmount
            }
          ]
        };
        sales.unshift(newSale);
        setStored(DB_KEYS.SALES, sales);
      }
      return { data: { success: true } };
    }
  },
};

export const reportsAPI = {
  getDashboard: async () => {
    try {
      return await api.get('/reports/dashboard');
    } catch {
      const products = getStored(DB_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      const customers = getStored(DB_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
      const sales = getStored(DB_KEYS.SALES, INITIAL_SALES);
      const payments = getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS);

      const totalSales = sales.reduce((acc, s) => acc + (parseFloat(s.total_amount) || 0), 0);
      const totalReceived = payments.reduce((acc, p) => acc + (parseFloat(p.amount_paid) || 0), 0);
      const totalPending = Math.max(0, totalSales - totalReceived);
      const totalStock = products.reduce((acc, p) => acc + (parseInt(p.quantity) || 0), 0);
      const lowStock = products.filter(p => p.quantity <= p.min_stock_threshold).length;

      return {
        data: {
          total_sales: totalSales,
          total_money_received: totalReceived,
          total_pending_balance: totalPending,
          total_products_count: products.length,
          total_stock_quantity: totalStock,
          low_stock_count: lowStock,
          total_customers: customers.length,
          recent_sales: sales.slice(0, 5)
        }
      };
    }
  },
  getAnalytics: async () => {
    try {
      return await api.get('/reports/analytics');
    } catch {
      const payments = getStored(DB_KEYS.PAYMENTS, INITIAL_PAYMENTS);
      const methods = {};
      payments.forEach(p => {
        const m = p.payment_method || 'Cash';
        methods[m] = (methods[m] || 0) + (parseFloat(p.amount_paid) || 0);
      });
      return {
        data: {
          weekly_trend: [
            { date: 'Mon', sales: 12000, received: 10000 },
            { date: 'Tue', sales: 15400, received: 14000 },
            { date: 'Wed', sales: 9000, received: 7500 },
            { date: 'Thu', sales: 18500, received: 16000 },
            { date: 'Fri', sales: 22000, received: 19500 },
            { date: 'Sat', sales: 31000, received: 28000 },
            { date: 'Sun', sales: 26000, received: 24000 },
          ],
          payment_methods: methods
        }
      };
    }
  }
};

export default api;

