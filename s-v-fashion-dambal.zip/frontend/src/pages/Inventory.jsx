import React, { useEffect, useState } from 'react';
import { Boxes, Plus, Minus, Search, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { productsAPI, formatCurrency } from '../services/api';

export default function Inventory() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all'); // all, low, out

  useEffect(() => {
    fetchInventory();
  }, [search]);

  const fetchInventory = async () => {
    try {
      setLoading(true);
      const res = await productsAPI.getAll({ search: search || undefined });
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAdjustStock = async (product, delta) => {
    const newQty = Math.max(0, product.quantity + delta);
    try {
      await productsAPI.update(product.id, {
        quantity: newQty,
        adjustment_reason: delta > 0 ? 'Stock Received / Added' : 'Stock Manually Reduced'
      });
      fetchInventory();
    } catch (err) {
      alert('Failed to adjust stock');
    }
  };

  const filteredProducts = products.filter(p => {
    if (filter === 'low') return p.quantity <= p.minimum_stock && p.quantity > 0;
    if (filter === 'out') return p.quantity <= 0;
    return true;
  });

  const totalStockItems = products.reduce((acc, p) => acc + p.quantity, 0);
  const totalStockValuation = products.reduce((acc, p) => acc + (p.purchase_price * p.quantity), 0);
  const totalRetailValuation = products.reduce((acc, p) => acc + (p.selling_price * p.quantity), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Stock & Inventory</h1>
          <p className="text-xs text-slate-500">Monitor stock levels, stock valuation, and restock clothes</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Total Stock Quantity</span>
          <h3 className="text-2xl font-extrabold text-slate-900 mt-1">{totalStockItems} pcs</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Across {products.length} product lines</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Inventory Cost Value</span>
          <h3 className="text-2xl font-extrabold text-indigo-600 mt-1">{formatCurrency(totalStockValuation)}</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Based on purchase cost</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500">Retail Sales Potential</span>
          <h3 className="text-2xl font-extrabold text-emerald-600 mt-1">{formatCurrency(totalRetailValuation)}</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">Estimated revenue value</p>
        </div>
      </div>

      {/* Search & Status Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search inventory..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          {['all', 'low', 'out'].map((mode) => (
            <button
              key={mode}
              onClick={() => setFilter(mode)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition ${
                filter === mode
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {mode === 'all' ? 'All Stock' : mode === 'low' ? 'Low Stock' : 'Out of Stock'}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Product</th>
                <th className="px-5 py-3.5">Gender / Brand</th>
                <th className="px-5 py-3.5">Cost Price</th>
                <th className="px-5 py-3.5">Selling Price</th>
                <th className="px-5 py-3.5 text-center">Stock Level</th>
                <th className="px-5 py-3.5 text-right">Adjust Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredProducts.map((p) => {
                const isOut = p.quantity <= 0;
                const isLow = p.quantity <= p.minimum_stock && !isOut;
                return (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition">
                    <td className="px-5 py-3.5 font-bold text-slate-900 flex items-center space-x-3">
                      <img
                        src={p.image_url || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=100'}
                        alt=""
                        className="w-9 h-9 rounded-lg object-cover bg-slate-100 flex-shrink-0"
                      />
                      <span className="truncate max-w-xs">{p.name}</span>
                    </td>
                    <td className="px-5 py-3.5 text-slate-500">
                      {p.gender} • {p.brand || 'ClothBook'}
                    </td>
                    <td className="px-5 py-3.5 font-medium">{formatCurrency(p.purchase_price)}</td>
                    <td className="px-5 py-3.5 font-bold text-slate-900">{formatCurrency(p.selling_price)}</td>
                    <td className="px-5 py-3.5 text-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-extrabold ${
                          isOut
                            ? 'bg-rose-50 text-rose-600 border border-rose-200'
                            : isLow
                            ? 'bg-amber-50 text-amber-600 border border-amber-200'
                            : 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                        }`}
                      >
                        {p.quantity} pcs
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="inline-flex items-center space-x-1.5">
                        <button
                          onClick={() => handleAdjustStock(p, -1)}
                          disabled={p.quantity <= 0}
                          className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 disabled:opacity-30"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleAdjustStock(p, 1)}
                          className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
