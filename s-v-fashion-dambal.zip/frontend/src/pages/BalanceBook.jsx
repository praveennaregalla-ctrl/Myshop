import React, { useEffect, useState } from 'react';
import { Scale, Search, AlertCircle, Plus, CheckCircle, ArrowUpRight, DollarSign } from 'lucide-react';
import { balanceAPI, paymentsAPI, formatCurrency } from '../services/api';

export default function BalanceBook() {
  const [data, setData] = useState({ records: [], total_pending_balance: 0, pending_customers_count: 0 });
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('pending'); // pending, paid, all
  const [search, setSearch] = useState('');

  // Collect Payment Modal
  const [collectModal, setCollectModal] = useState(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('Cash');

  // Add Due Modal
  const [dueModal, setDueModal] = useState(null);
  const [dueAmount, setDueAmount] = useState('');
  const [dueItemName, setDueItemName] = useState('Clothing Purchase Credit');

  useEffect(() => {
    fetchBalances();
  }, [statusFilter, search]);

  const fetchBalances = async () => {
    try {
      setLoading(true);
      const res = await balanceAPI.getAll({
        status: statusFilter !== 'all' ? statusFilter : undefined,
        search: search || undefined
      });
      setData(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCollectPayment = async (e) => {
    e.preventDefault();
    try {
      await paymentsAPI.create({
        customer_id: collectModal.customer_id,
        customer_name: collectModal.customer_name,
        amount_paid: parseFloat(payAmount),
        payment_method: payMethod,
        item_description: `Balance Collection (${collectModal.customer_name})`
      });
      setCollectModal(null);
      setPayAmount('');
      fetchBalances();
    } catch (err) {
      alert('Failed to collect payment');
    }
  };

  const handleAddDue = async (e) => {
    e.preventDefault();
    try {
      await balanceAPI.addDue({
        customer_id: dueModal.customer_id,
        amount: parseFloat(dueAmount),
        item_description: dueItemName
      });
      setDueModal(null);
      setDueAmount('');
      fetchBalances();
    } catch (err) {
      alert('Failed to add due');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Customer Balance Book</h1>
        <p className="text-xs text-slate-500">Track outstanding dues, itemized cloth purchase history with individual amounts, and collect payments</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-gradient-to-r from-rose-500 to-red-600 rounded-2xl p-5 text-white shadow-lg shadow-rose-500/10">
          <span className="text-xs font-bold text-rose-100 uppercase tracking-wider">Total Outstanding Market Due</span>
          <h3 className="text-3xl font-extrabold mt-1">{formatCurrency(data.total_pending_balance)}</h3>
          <p className="text-xs text-rose-100 mt-1">{data.pending_customers_count} customers with pending balance</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase">Filtered Total</span>
            <h3 className="text-2xl font-extrabold text-slate-900 mt-1">
              {formatCurrency(data.records.reduce((acc, r) => acc + r.remaining_balance, 0))}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">{data.records.length} ledger entries</p>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
            <Scale className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search customer balance..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="flex items-center space-x-2">
          {['pending', 'paid', 'all'].map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition ${
                statusFilter === tab
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {tab === 'pending' ? 'Pending Dues' : tab === 'paid' ? 'Fully Cleared' : 'All Accounts'}
            </button>
          ))}
        </div>
      </div>

      {/* Balance Cards List with Itemized Purchases */}
      <div className="space-y-4">
        {data.records.map((rec) => (
          <div
            key={rec.customer_id}
            className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-5 space-y-4 hover:shadow-md transition"
          >
            {/* Top Row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-700 font-extrabold flex items-center justify-center text-sm">
                  {rec.customer_name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">{rec.customer_name}</h3>
                  <p className="text-xs text-slate-400 font-medium">📞 {rec.customer_phone}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Pending Due</span>
                  <span
                    className={`text-lg font-extrabold ${
                      rec.remaining_balance > 0 ? 'text-rose-600' : 'text-emerald-600'
                    }`}
                  >
                    {formatCurrency(rec.remaining_balance)}
                  </span>
                </div>

                {/* Actions */}
                <div className="flex items-center space-x-2">
                  {rec.remaining_balance > 0 && (
                    <button
                      onClick={() => {
                        setCollectModal(rec);
                        setPayAmount(rec.remaining_balance.toString());
                      }}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition shadow-sm"
                    >
                      Collect Payment
                    </button>
                  )}
                  <button
                    onClick={() => setDueModal(rec)}
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
                  >
                    + Add Due
                  </button>
                </div>
              </div>
            </div>

            {/* Financial Status Summary */}
            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 p-3 rounded-xl">
              <div>
                <span className="text-slate-400 font-medium">Total Billed:</span>
                <p className="font-bold text-slate-900">{formatCurrency(rec.total_purchase_amount)}</p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Total Paid:</span>
                <p className="font-bold text-emerald-600">{formatCurrency(rec.total_amount_paid)}</p>
              </div>
              <div>
                <span className="text-slate-400 font-medium">Status:</span>
                <p className="font-bold text-slate-800">{rec.status}</p>
              </div>
            </div>

            {/* Itemized Purchase Details */}
            {rec.purchased_items && rec.purchased_items.length > 0 && (
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Purchased Items & Amount Details ({rec.purchased_items.length})
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {rec.purchased_items.map((it, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2.5 bg-slate-50/60 rounded-xl border border-slate-100 text-xs"
                    >
                      <div className="truncate pr-2">
                        <p className="font-bold text-slate-800 truncate">{it.product_name}</p>
                        <p className="text-[10px] text-slate-400">
                          Qty: {it.quantity} • {it.size !== '-' ? `Size: ${it.size}` : ''} • Inv #{it.invoice_number}
                        </p>
                      </div>
                      <span className="font-extrabold text-slate-900 whitespace-nowrap">
                        {formatCurrency(it.total_price)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Collect Modal */}
      {collectModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-base text-slate-900">Collect Payment from {collectModal.customer_name}</h3>
            <p className="text-xs text-rose-600 font-semibold">
              Current Due: {formatCurrency(collectModal.remaining_balance)}
            </p>
            <form onSubmit={handleCollectPayment} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Amount to Collect (₹) *</label>
                <input
                  type="number"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                >
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="Card">Card</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCollectModal(null)}
                  className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 shadow-md"
                >
                  Save & Update Balance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Due Modal */}
      {dueModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-base text-slate-900">Add Credit Due to {dueModal.customer_name}</h3>
            <form onSubmit={handleAddDue} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Due Amount (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="0"
                  value={dueAmount}
                  onChange={(e) => setDueAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Purchased Item Description</label>
                <input
                  type="text"
                  value={dueItemName}
                  onChange={(e) => setDueItemName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDueModal(null)}
                  className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 shadow-md"
                >
                  Add Due Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
