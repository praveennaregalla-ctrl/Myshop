import React, { useEffect, useState } from 'react';
import { Sparkles, ShoppingBag } from 'lucide-react';
import { productsAPI } from '../services/api';
import ProductCard from '../components/ProductCard';

export default function NewArrivals() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNewArrivals();
  }, []);

  const fetchNewArrivals = async () => {
    try {
      setLoading(true);
      const res = await productsAPI.getNewArrivals();
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-orange-500/10">
        <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full w-fit text-xs font-extrabold mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>LATEST SEASON DROPS</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">New Arrivals Collection</h1>
        <p className="text-sm text-orange-100 mt-1 max-w-xl">
          Freshly stocked fabrics, festive collections, and trending apparel ready for sale.
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
        </div>
      ) : products.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <Sparkles className="w-12 h-12 mx-auto text-amber-300 mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No New Arrivals Marked</h3>
          <p className="text-xs text-slate-400 mt-1">Mark items as 'New Arrival' from the product catalog or add new clothes.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
