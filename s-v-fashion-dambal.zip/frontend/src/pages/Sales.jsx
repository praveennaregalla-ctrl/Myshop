import React, { useState, useEffect } from 'react';
import { ShoppingBag, Plus, Minus, Trash2, CheckCircle2, Printer, Search, UserCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { customersAPI, salesAPI, formatCurrency } from '../services/api';

export default function Sales() {
  const { cartItems, updateQuantity, removeFromCart, clearCart, discount, setDiscount, subtotal, total } = useCart();
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [amountPaid, setAmountPaid] = useState('');
  const [notes, setNotes] = useState('');
  const [completedSale, setCompletedSale] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // New Customer quick modal state
  const [showNewCust, setShowNewCust] = useState(false);
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');

  useEffect(() => {
    fetchCustomers();
  }, []);

  useEffect(() => {
    // Default amountPaid to full total when total changes
    setAmountPaid(total.toString());
  }, [total]);

  const fetchCustomers = async () => {
    try {
      const res = await customersAPI.getAll();
      setCustomers(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateCustomer = async (e) => {
    e.preventDefault();
    try {
      const res = await customersAPI.create({ name: custName, phone: custPhone });
      setCustomers([res.data, ...customers]);
      setSelectedCustomer(res.data);
      setShowNewCust(false);
      setCustName('');
      setCustPhone('');
    } catch (err) {
      alert('Failed to create customer');
    }
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) return alert('Cart is empty!');
    
    const paidVal = parseFloat(amountPaid || 0);
    const dueVal = Math.max(0, total - paidVal);

    if (dueVal > 0 && !selectedCustomer) {
      return alert('Please select or add a Customer for credit / partial balance sales!');
    }

    try {
      setIsProcessing(true);
      const payload = {
        customer_id: selectedCustomer?.id || null,
        customer_name: selectedCustomer?.name || 'Walk-in Customer',
        customer_phone: selectedCustomer?.phone || '',
        subtotal,
        discount,
        total_amount: total,
        amount_paid: paidVal,
        remaining_balance: dueVal,
        payment_method: paymentMethod,
        notes,
        items: cartItems.map(item => ({
          product_id: item.product.id,
          product_name: item.product.name,
          size: item.size,
          color: item.color,
          quantity: item.quantity,
          unit_price: item.unitPrice,
          total_price: item.unitPrice * item.quantity
        }))
      };

      const res = await salesAPI.create(payload);
      setCompletedSale(res.data);
      clearCart();
    } catch (err) {
      alert(err.response?.data?.error || 'Sale failed!');
    } finally {
      setIsProcessing(false);
    }
  };

  const paymentMethods = ['Cash', 'UPI / GPay / PhonePe', 'Card', 'Net Banking'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Point of Sale (POS) Billing</h1>
        <p className="text-xs text-slate-500">Checkout cart items, assign customer dues, and generate invoices</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-slate-900 text-base flex items-center space-x-2">
                <ShoppingBag className="w-5 h-5 text-indigo-600" />
                <span>Selected Clothing Items ({cartItems.length})</span>
              </h2>
              {cartItems.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700"
                >
                  Clear Cart
                </button>
              )}
            </div>

            {cartItems.length === 0 ? (
              <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-2xl">
                <ShoppingBag className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                <p className="font-bold text-slate-700 text-sm">Your POS Cart is Empty</p>
                <p className="text-xs text-slate-400 mt-1">Visit the Products or New Arrivals catalog to add items.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {cartItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200/80"
                  >
                    <div className="flex items-center space-x-3 truncate">
                      <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center font-bold text-indigo-600 text-xs flex-shrink-0">
                        {item.size}
                      </div>
                      <div className="truncate">
                        <p className="font-bold text-slate-900 text-xs sm:text-sm truncate">{item.product.name}</p>
                        <p className="text-[11px] text-slate-400">
                          {formatCurrency(item.unitPrice)} each • Size: {item.size}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 flex-shrink-0">
                      <div className="flex items-center space-x-1.5 bg-white border border-slate-200 rounded-lg p-1">
                        <button
                          onClick={() => updateQuantity(idx, -1)}
                          className="p-1 rounded text-slate-500 hover:bg-slate-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold w-5 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(idx, 1)}
                          className="p-1 rounded text-slate-500 hover:bg-slate-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <span className="font-extrabold text-slate-900 text-xs sm:text-sm w-20 text-right">
                        {formatCurrency(item.unitPrice * item.quantity)}
                      </span>

                      <button
                        onClick={() => removeFromCart(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Checkout Summary & Customer Assignment */}
        <div className="space-y-4">
          {/* Customer Selection */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">Customer (Required for Dues)</label>
              <button
                onClick={() => setShowNewCust(true)}
                className="text-xs text-indigo-600 font-bold hover:underline"
              >
                + New Customer
              </button>
            </div>

            <select
              value={selectedCustomer?.id || ''}
              onChange={(e) => {
                const c = customers.find(x => x.id === parseInt(e.target.value));
                setSelectedCustomer(c || null);
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-600 focus:outline-none"
            >
              <option value="">-- Walk-in / Cash Customer --</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone}) - Due: {formatCurrency(c.remaining_balance)}
                </option>
              ))}
            </select>

            {selectedCustomer && (
              <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-xs space-y-1">
                <p className="font-bold text-indigo-900">{selectedCustomer.name}</p>
                <p className="text-indigo-700">Phone: {selectedCustomer.phone}</p>
                <p className="text-rose-600 font-semibold">Existing Dues: {formatCurrency(selectedCustomer.remaining_balance)}</p>
              </div>
            )}
          </div>

          {/* Payment & Bill Summary */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-900 text-sm border-b border-slate-100 pb-2">Payment Details</h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span className="font-semibold text-slate-800">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-500">
                <span>Discount (₹)</span>
                <input
                  type="number"
                  placeholder="0"
                  value={discount || ''}
                  onChange={(e) => setDiscount(parseFloat(e.target.value || 0))}
                  className="w-24 text-right px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                />
              </div>
              <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-100">
                <span>Net Total</span>
                <span className="text-indigo-600 text-base">{formatCurrency(total)}</span>
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none"
              >
                {paymentMethods.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            {/* Amount Paid & Remaining Balance */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Paid Now (₹)</label>
                <input
                  type="number"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Balance Due</label>
                <div className="px-3 py-2 bg-rose-50 border border-rose-100 rounded-xl text-xs font-extrabold text-rose-600">
                  {formatCurrency(Math.max(0, total - parseFloat(amountPaid || 0)))}
                </div>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={isProcessing || cartItems.length === 0}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 transition flex items-center justify-center space-x-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Complete Sale & Invoice</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Add Customer Modal */}
      {showNewCust && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900 mb-3">Add Quick Customer</h3>
            <form onSubmit={handleCreateCustomer} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Anand Kumar"
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98..."
                  value={custPhone}
                  onChange={(e) => setCustPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewCust(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Completed Sale Invoice Modal */}
      {completedSale && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="text-center pb-3 border-b border-slate-100">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="font-extrabold text-lg text-slate-900">S V FASHION DAMBAL</h2>
              <p className="text-xs text-slate-400">Invoice #{completedSale.invoice_number}</p>
            </div>

            <div className="text-xs space-y-2 text-slate-600">
              <div className="flex justify-between">
                <span>Customer:</span>
                <span className="font-bold text-slate-900">{completedSale.customer_name}</span>
              </div>
              <div className="flex justify-between">
                <span>Payment Mode:</span>
                <span className="font-semibold text-indigo-600">{completedSale.payment_method}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Amount:</span>
                <span className="font-bold text-slate-900">{formatCurrency(completedSale.total_amount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Amount Paid:</span>
                <span className="font-bold text-emerald-600">{formatCurrency(completedSale.amount_paid)}</span>
              </div>
              {completedSale.remaining_balance > 0 && (
                <div className="flex justify-between text-rose-600 font-bold bg-rose-50 p-2 rounded-lg">
                  <span>Balance Due:</span>
                  <span>{formatCurrency(completedSale.remaining_balance)}</span>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-3 pt-3 border-t border-slate-100">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center space-x-2"
              >
                <Printer className="w-4 h-4" />
                <span>Print Bill</span>
              </button>
              <button
                onClick={() => setCompletedSale(null)}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
