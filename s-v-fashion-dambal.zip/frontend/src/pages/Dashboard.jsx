import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  CreditCard,
  AlertCircle,
  Package,
  Users,
  Calendar,
  ArrowUpRight,
  Sparkles,
  ShoppingBag
} from 'lucide-react';
import { reportsAPI, formatCurrency } from '../services/api';
import { Link } from 'react-router-dom';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [dashRes, analRes] = await Promise.all([
        reportsAPI.getDashboard(),
        reportsAPI.getAnalytics()
      ]);
      setData(dashRes.data);
      setAnalytics(analRes.data);
    } catch (err) {
      console.error("Error fetching dashboard:", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Today's Sales",
      value: formatCurrency(data?.today_sales || 0),
      subtitle: `Total Sales: ${formatCurrency(data?.total_sales || 0)}`,
      icon: TrendingUp,
      bg: "bg-indigo-50 text-indigo-600 border-indigo-100",
    },
    {
      title: "Money Received",
      value: formatCurrency(data?.today_money_received || 0),
      subtitle: `Total Collected: ${formatCurrency(data?.total_money_received || 0)}`,
      icon: CreditCard,
      bg: "bg-emerald-50 text-emerald-600 border-emerald-100",
    },
    {
      title: "Pending Balance (Dues)",
      value: formatCurrency(data?.total_pending_balance || 0),
      subtitle: "Customer Credit Book",
      icon: AlertCircle,
      bg: "bg-rose-50 text-rose-600 border-rose-100",
    },
    {
      title: "Active Inventory",
      value: `${data?.total_stock_items || 0} items`,
      subtitle: `${data?.total_products || 0} unique clothing styles`,
      icon: Package,
      bg: "bg-amber-50 text-amber-600 border-amber-100",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl shadow-indigo-950/10">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-indigo-200 text-xs font-semibold mb-3 border border-white/10">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Store Command Center</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">S V FASHION DAMBAL</h1>
          <p className="text-sm text-indigo-200 mt-1">
            Smart clothing inventory, POS billing, daily payment register, and customer balance book.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link
              to="/sales"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2 rounded-xl text-xs sm:text-sm flex items-center space-x-2 transition shadow-md shadow-indigo-600/30"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Open POS Billing</span>
            </Link>
            <Link
              to="/balances"
              className="bg-white/10 hover:bg-white/20 text-white font-semibold px-4 py-2 rounded-xl text-xs sm:text-sm backdrop-blur-md transition border border-white/10"
            >
              <span>View Balance Book</span>
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">{card.title}</span>
                <div className={`p-2 rounded-xl border ${card.bg}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">{card.value}</h3>
                <p className="text-xs text-slate-400 font-medium mt-0.5">{card.subtitle}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts & Activity Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Revenue Chart */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold text-slate-900 text-base">Weekly Revenue & Collections</h2>
              <p className="text-xs text-slate-400">Past 7 days sales vs collected payments</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.weekly_trend || []}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
                <Tooltip
                  formatter={(val) => [formatCurrency(val), 'Amount']}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }}
                />
                <Bar dataKey="sales" name="Sales (₹)" fill="#6366f1" radius={[6, 6, 0, 0]} />
                <Bar dataKey="received" name="Received (₹)" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-slate-900 text-base">Low Stock Alerts</h2>
              <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100">
                {data?.low_stock_count || 0} low
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4">Items requiring restock soon</p>

            <div className="space-y-3">
              {(data?.low_stock_products || []).slice(0, 4).map((p) => (
                <div key={p.id} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="truncate pr-2">
                    <p className="text-xs font-bold text-slate-800 truncate">{p.name}</p>
                    <p className="text-[10px] text-slate-400">{p.gender} • {p.brand}</p>
                  </div>
                  <span className="text-xs font-bold text-rose-600 bg-white px-2 py-1 rounded-md border border-rose-200 shadow-xs">
                    {p.quantity} left
                  </span>
                </div>
              ))}

              {(data?.low_stock_products || []).length === 0 && (
                <p className="text-xs text-emerald-600 font-semibold text-center py-6">
                  ✓ All products have adequate inventory!
                </p>
              )}
            </div>
          </div>

          <Link
            to="/inventory"
            className="mt-4 w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center space-x-1.5 transition"
          >
            <span>Manage All Stock</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
