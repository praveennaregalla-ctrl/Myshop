import React, { useEffect, useState } from 'react';
import { BookOpenCheck, Calendar as CalendarIcon, Plus, CreditCard, Filter, ArrowDownRight } from 'lucide-react';
import { paymentsAPI, customersAPI, formatCurrency } from '../services/api';

export default function PaymentBook() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentsData, setPaymentsData] = useState({ payments: [], daily_total: 0, count: 0 });
  const [loading, setLoading] = useState(true);
  const [showAddPayment, setShowAddPayment] = useState(false);

  // Add payment form
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [amountPaid, setAmountPaid] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [itemDescription, setItemDescription] = useState('Payment Received');
  const [paymentNotes, setPaymentNotes] = useState('');

  useEffect(() => {
    fetchDailyPayments();
  }, [selectedDate]);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchDailyPayments = async () => {
    try {
      setLoading(true);
      const res = await paymentsAPI.getByDate(selectedDate);
      setPaymentsData(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await customersAPI.getAll({ has_due: 'true' });
      setCustomers(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleRecordPayment = async (e) => {
    e.preventDefault();
    try {
      await paymentsAPI.create({
        customer_id: selectedCustomer?.id || null,
        customer_name: selectedCustomer?.name || 'Walk-in Customer',
        amount_paid: parseFloat(amountPaid),
        payment_method: paymentMethod,
        item_description: itemDescription,
        payment_notes: paymentNotes,
        payment_date: selectedDate
      });
      setShowAddPayment(false);
      setAmountPaid('');
      fetchDailyPayments();
    } catch (err) {
      alert('Failed to record payment');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Daily Payment Book</h1>
          <p className="text-xs text-slate-500">Date-wise accounting payment register with auto-computed daily collections</p>
        </div>
        <button
          onClick={() => setShowAddPayment(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl flex items-center space-x-2 transition shadow-md shadow-indigo-600/20 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Record Payment</span>
        </button>
      </div>

      {/* Date & Daily Summary Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3 w-full md:w-auto">
          <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase">Selected Register Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="font-extrabold text-slate-900 text-sm sm:text-base bg-transparent border-none focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        {/* Daily Total Display */}
        <div className="bg-emerald-50 border border-emerald-100 rounded-xl px-5 py-3 flex items-center space-x-4 w-full md:w-auto justify-between md:justify-start">
          <div>
            <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
              Daily Total Received
            </span>
            <span className="text-xl font-extrabold text-emerald-700">
              {formatCurrency(paymentsData.daily_total)}
            </span>
          </div>
          <span className="text-xs font-bold text-emerald-800 bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
            {paymentsData.count} transactions
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Customer Name</th>
                <th className="px-5 py-3.5">Item / Reason</th>
                <th className="px-5 py-3.5">Payment Mode</th>
                <th className="px-5 py-3.5">Notes</th>
                <th className="px-5 py-3.5 text-right">Amount Received</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {paymentsData.payments.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/80 transition">
                  <td className="px-5 py-3.5 font-bold text-slate-900">{p.customer_name}</td>
                  <td className="px-5 py-3.5 text-slate-600">{p.item_description}</td>
                  <td className="px-5 py-3.5">
                    <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 font-bold text-[11px] border border-indigo-100">
                      {p.payment_method}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-slate-400 text-xs">{p.payment_notes || '-'}</td>
                  <td className="px-5 py-3.5 font-extrabold text-emerald-600 text-right text-sm">
                    +{formatCurrency(p.amount_paid)}
                  </td>
                </tr>
              ))}

              {paymentsData.payments.length === 0 && (
                <tr>
                  <td colSpan="5" className="py-12 text-center text-slate-400">
                    No payment entries recorded for {selectedDate}.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {showAddPayment && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Record Direct Payment</h2>
            <form onSubmit={handleRecordPayment} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Customer (Optional)</label>
                <select
                  value={selectedCustomer?.id || ''}
                  onChange={(e) => {
                    const c = customers.find(x => x.id === parseInt(e.target.value));
                    setSelectedCustomer(c || null);
                  }}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                >
                  <option value="">-- Direct Payment / Walk-in --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} (Due: {formatCurrency(c.remaining_balance)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Amount Received (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="0"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                  >
                    <option value="Cash">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="Card">Card</option>
                    <option value="Net Banking">Net Banking</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
                  <input
                    type="text"
                    value={itemDescription}
                    onChange={(e) => setItemDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddPayment(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow-md"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
