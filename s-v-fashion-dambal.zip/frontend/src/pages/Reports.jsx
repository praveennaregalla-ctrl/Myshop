import React, { useEffect, useState } from 'react';
import { BarChart3, TrendingUp, PieChart, CreditCard, ArrowUpRight } from 'lucide-react';
import { reportsAPI, formatCurrency } from '../services/api';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart as RechartsPie, Pie, Cell } from 'recharts';

export default function Reports() {
  const [dashboard, setDashboard] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [dash, anal] = await Promise.all([
        reportsAPI.getDashboard(),
        reportsAPI.getAnalytics()
      ]);
      setDashboard(dash.data);
      setAnalytics(anal.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];
  const paymentMethodPieData = Object.entries(analytics?.payment_methods || {}).map(([name, value]) => ({
    name,
    value
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Business Analytics & Reports</h1>
        <p className="text-xs text-slate-500">Financial insights, collection ratios, and revenue distribution</p>
      </div>

      {/* Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase">Gross Sales Revenue</span>
          <h3 className="text-2xl font-extrabold text-indigo-600 mt-1">{formatCurrency(dashboard?.total_sales)}</h3>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase">Net Realized Cash</span>
          <h3 className="text-2xl font-extrabold text-emerald-600 mt-1">{formatCurrency(dashboard?.total_money_received)}</h3>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase">Uncollected Credit</span>
          <h3 className="text-2xl font-extrabold text-rose-600 mt-1">{formatCurrency(dashboard?.total_pending_balance)}</h3>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-sm mb-1">Sales vs. Payment Inflow (Last 7 Days)</h3>
          <p className="text-xs text-slate-400 mb-4">Comparison of invoiced total vs collected cash</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.weekly_trend || []}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(val) => [formatCurrency(val), 'Amount']} />
                <Bar dataKey="sales" name="Sales" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="received" name="Received" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-sm mb-1">Payment Method Distribution</h3>
          <p className="text-xs text-slate-400 mb-4">Cash vs UPI vs Card breakdown</p>
          <div className="h-64 flex items-center justify-center">
            {paymentMethodPieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPie>
                  <Pie
                    data={paymentMethodPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {paymentMethodPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val) => [formatCurrency(val), 'Collected']} />
                </RechartsPie>
              </ResponsiveContainer>
            ) : (
              <p className="text-xs text-slate-400">No payment transaction records yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
