import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Shirt,
  Sparkles,
  Boxes,
  ShoppingCart,
  Users,
  BookOpenCheck,
  Scale,
  BarChart3,
  Settings,
  X
} from 'lucide-react';

const navItems = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Products', path: '/products', icon: Shirt },
  { name: 'New Arrivals', path: '/new-arrivals', icon: Sparkles },
  { name: 'Inventory', path: '/inventory', icon: Boxes },
  { name: 'POS & Sales', path: '/sales', icon: ShoppingCart },
  { name: 'Customers', path: '/customers', icon: Users },
  { name: 'Payment Book', path: '/payments', icon: BookOpenCheck },
  { name: 'Balance Book', path: '/balances', icon: Scale },
  { name: 'Reports', path: '/reports', icon: BarChart3 },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export default function Sidebar({ isOpen, onClose }) {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-0 left-0 bottom-0 w-64 bg-slate-900 text-white z-50 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <img
              src="/app_icon.jpg"
              alt="SV Fashion Logo"
              className="w-10 h-10 rounded-xl object-cover border border-amber-500/30 shadow-md shadow-amber-500/10"
            />
            <div>
              <h1 className="font-bold text-sm leading-tight tracking-tight text-white">S V FASHION</h1>
              <p className="text-[10px] text-amber-400 font-semibold tracking-wider">DAMBAL • POS</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`
                }
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.name}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Footer / Status */}
        <div className="p-4 border-t border-slate-800">
          <div className="bg-slate-800/80 rounded-xl p-3 flex items-center space-x-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <div className="text-xs">
              <p className="text-white font-medium">S V FASHION DAMBAL</p>
              <p className="text-slate-400 text-[11px]">System Online (₹ INR)</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
