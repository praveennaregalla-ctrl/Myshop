import React from 'react';
import { Menu, ShoppingBag, Bell, Search } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';
import { formatCurrency } from '../services/api';

export default function Navbar({ onMenuClick }) {
  const { cartItems, total } = useCart();
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="h-16 bg-white border-b border-slate-200/80 sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6">
      <div className="flex items-center space-x-4">
        <button
          onClick={onMenuClick}
          className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:flex items-center text-xs text-slate-500 font-medium space-x-2">
          <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
            ClothBook v1.0
          </span>
          <span className="text-slate-300">•</span>
          <span>Desktop & POS Web Portal</span>
        </div>
      </div>

      <div className="flex items-center space-x-3 sm:space-x-4">
        {/* Cart Quick Button */}
        <Link
          to="/sales"
          className="flex items-center space-x-2.5 bg-indigo-50 hover:bg-indigo-100/80 text-indigo-700 px-3.5 py-2 rounded-xl transition border border-indigo-200/60"
        >
          <div className="relative">
            <ShoppingBag className="w-4 h-4" />
            {totalCartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-indigo-600 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {totalCartCount}
              </span>
            )}
          </div>
          <span className="text-xs font-bold hidden sm:inline">
            Cart: {formatCurrency(total)}
          </span>
        </Link>

        {/* Store Profile */}
        <div className="flex items-center space-x-3 border-l border-slate-200 pl-3 sm:pl-4">
          <div className="w-8 h-8 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs shadow-sm">
            SV
          </div>
          <div className="hidden md:block text-left">
            <p className="text-xs font-bold text-slate-800 leading-none">Shop Admin</p>
            <p className="text-[10px] text-slate-400 font-medium">Main Counter</p>
          </div>
        </div>
      </div>
    </header>
  );
}
