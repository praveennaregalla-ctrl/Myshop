import React, { useState } from 'react';
import { ShoppingCart, Check, Sparkles } from 'lucide-react';
import { formatCurrency } from '../services/api';
import { useCart } from '../context/CartContext';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const [selectedSize, setSelectedSize] = useState('M');
  const [added, setAdded] = useState(false);

  const sizes = ['S', 'M', 'L', 'XL'];

  const handleAdd = () => {
    addToCart(product, selectedSize, 'Standard');
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };

  const isLowStock = product.quantity <= product.minimum_stock;
  const isOutOfStock = product.quantity <= 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition group">
      {/* Image & Badges */}
      <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden">
        <img
          src={product.image_url || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=500&q=80'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
        />
        {product.is_new_arrival && (
          <div className="absolute top-2.5 left-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-lg flex items-center space-x-1 shadow-md">
            <Sparkles className="w-3 h-3" />
            <span>NEW ARRIVAL</span>
          </div>
        )}
        <div className="absolute top-2.5 right-2.5">
          <span className="bg-white/90 backdrop-blur-md text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-md border border-slate-200 shadow-sm">
            {product.gender || 'Unisex'}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>{product.brand || product.category_name || 'ClothBook'}</span>
            <span className={`font-semibold ${isOutOfStock ? 'text-rose-600' : isLowStock ? 'text-amber-600' : 'text-emerald-600'}`}>
              {isOutOfStock ? 'Out of Stock' : `${product.quantity} in stock`}
            </span>
          </div>

          <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-1 group-hover:text-indigo-600 transition">
            {product.name}
          </h3>

          <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
            {product.description || 'Premium fabric clothing design.'}
          </p>

          {/* Size Selectors */}
          <div className="mt-3 flex items-center space-x-1.5">
            <span className="text-[11px] text-slate-400 font-medium mr-1">Size:</span>
            {sizes.map((sz) => (
              <button
                key={sz}
                onClick={() => setSelectedSize(sz)}
                className={`text-[11px] font-bold w-6 h-6 rounded-md border transition ${
                  selectedSize === sz
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>

        {/* Price & Add to Cart */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-semibold block uppercase">Selling Price</span>
            <span className="text-base font-extrabold text-slate-900">
              {formatCurrency(product.selling_price)}
            </span>
          </div>

          <button
            onClick={handleAdd}
            disabled={isOutOfStock}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition ${
              added
                ? 'bg-emerald-600 text-white'
                : isOutOfStock
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-600/30'
            }`}
          >
            {added ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
