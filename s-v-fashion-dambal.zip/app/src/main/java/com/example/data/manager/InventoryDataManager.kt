package com.example.data.manager

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.entities.ProductEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Room & Firestore Hybrid Data Manager for Inventory Storage.
 *
 * Provides persistent local caching and query capabilities via Room Database,
 * while seamlessly synchronizing inventory items, stock levels, and changes
 * with Cloud Firestore for long-term multi-session cloud backup.
 */
class InventoryDataManager(
    private val database: AppDatabase,
    private val context: Context? = null
) {
    private val productDao = database.productDao()

    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firestore initialization skipped/unavailable: ${e.message}")
            null
        }
    }

    companion object {
        private const val TAG = "InventoryDataManager"
        private const val COLLECTION_INVENTORY = "inventory"

        @Volatile
        private var INSTANCE: InventoryDataManager? = null

        fun getInstance(context: Context): InventoryDataManager {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.getDatabase(context)
                val instance = InventoryDataManager(db, context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    /**
     * Observe all inventory products reactively from Room.
     */
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = productDao.getLowStockProducts()
    val newArrivals: Flow<List<ProductEntity>> = productDao.getNewArrivals()

    /**
     * Saves or updates a product in the local Room database and synchronizes with Firestore.
     */
    suspend fun saveProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        val id = if (product.id == 0L) {
            productDao.insertProduct(product)
        } else {
            productDao.updateProduct(product)
            product.id
        }

        val updatedProduct = product.copy(id = id)
        syncProductToFirestore(updatedProduct)
        id
    }

    /**
     * Updates the stock quantity of a product in Room and Firestore.
     */
    suspend fun updateStockQuantity(productId: Long, newQuantity: Int) = withContext(Dispatchers.IO) {
        val product = productDao.getProductById(productId)
        if (product != null) {
            val updated = product.copy(quantity = newQuantity)
            productDao.updateProduct(updated)
            syncProductToFirestore(updated)
        }
    }

    /**
     * Reduces product stock (e.g. on POS sale) in Room and Firestore.
     */
    suspend fun reduceStock(productId: Long, quantity: Int) = withContext(Dispatchers.IO) {
        productDao.reduceStock(productId, quantity)
        val product = productDao.getProductById(productId)
        if (product != null) {
            syncProductToFirestore(product)
        }
    }

    /**
     * Deletes a product from both Room and Firestore.
     */
    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(product)
        deleteProductFromFirestore(product.id)
    }

    /**
     * Deletes a product by ID from both Room and Firestore.
     */
    suspend fun deleteProductById(id: Long) = withContext(Dispatchers.IO) {
        productDao.deleteProductById(id)
        deleteProductFromFirestore(id)
    }

    /**
     * Syncs a single product document to Firestore.
     */
    private suspend fun syncProductToFirestore(product: ProductEntity) {
        try {
            val db = firestore ?: return
            val docData = hashMapOf(
                "id" to product.id,
                "name" to product.name,
                "category" to product.category,
                "brand" to product.brand,
                "size" to product.size,
                "color" to product.color,
                "purchasePrice" to product.purchasePrice,
                "sellingPrice" to product.sellingPrice,
                "quantity" to product.quantity,
                "minStockThreshold" to product.minStockThreshold,
                "dateAdded" to product.dateAdded,
                "supplierDetails" to product.supplierDetails,
                "imageDrawableName" to product.imageDrawableName,
                "imageUri" to product.imageUri,
                "description" to product.description,
                "isNewArrival" to product.isNewArrival,
                "lastUpdated" to System.currentTimeMillis()
            )

            db.collection(COLLECTION_INVENTORY)
                .document(product.id.toString())
                .set(docData, SetOptions.merge())
                .await()
            Log.d(TAG, "Successfully synced product ${product.name} (ID: ${product.id}) to Firestore.")
        } catch (e: Exception) {
            Log.w(TAG, "Firestore sync skipped/offline for product ${product.id}: ${e.message}")
        }
    }

    /**
     * Removes a product document from Firestore.
     */
    private suspend fun deleteProductFromFirestore(productId: Long) {
        try {
            val db = firestore ?: return
            db.collection(COLLECTION_INVENTORY)
                .document(productId.toString())
                .delete()
                .await()
            Log.d(TAG, "Deleted product $productId from Firestore.")
        } catch (e: Exception) {
            Log.w(TAG, "Firestore delete skipped/offline for product $productId: ${e.message}")
        }
    }

    /**
     * Full two-way synchronization between local Room and remote Firestore.
     */
    suspend fun syncWithFirestore() = withContext(Dispatchers.IO) {
        try {
            val db = firestore ?: return@withContext
            val snapshot = db.collection(COLLECTION_INVENTORY).get().await()

            if (!snapshot.isEmpty) {
                val remoteProducts = snapshot.documents.mapNotNull { doc ->
                    try {
                        ProductEntity(
                            id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L),
                            name = doc.getString("name") ?: "",
                            category = doc.getString("category") ?: "Clothing",
                            brand = doc.getString("brand") ?: "",
                            size = doc.getString("size") ?: "M",
                            color = doc.getString("color") ?: "",
                            purchasePrice = doc.getDouble("purchasePrice") ?: 0.0,
                            sellingPrice = doc.getDouble("sellingPrice") ?: 0.0,
                            quantity = doc.getLong("quantity")?.toInt() ?: 0,
                            minStockThreshold = doc.getLong("minStockThreshold")?.toInt() ?: 5,
                            dateAdded = doc.getLong("dateAdded") ?: System.currentTimeMillis(),
                            supplierDetails = doc.getString("supplierDetails") ?: "",
                            imageDrawableName = doc.getString("imageDrawableName") ?: "",
                            imageUri = doc.getString("imageUri") ?: "",
                            description = doc.getString("description") ?: "",
                            isNewArrival = doc.getBoolean("isNewArrival") ?: false
                        )
                    } catch (e: Exception) {
                        null
                    }
                }

                if (remoteProducts.isNotEmpty()) {
                    productDao.insertProducts(remoteProducts)
                    Log.d(TAG, "Imported ${remoteProducts.size} inventory items from Firestore into Room.")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not fetch inventory from Firestore: ${e.message}")
        }
    }
}
