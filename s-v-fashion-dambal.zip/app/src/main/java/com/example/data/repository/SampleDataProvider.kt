package com.example.data.repository

import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.PaymentRecordEntity
import com.example.data.local.entities.ProductEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.local.entities.SaleItemEntity
import com.example.data.local.entities.StoreSettingsEntity

object SampleDataProvider {
    fun getInitialProducts(): List<ProductEntity> = listOf(
        ProductEntity(
            id = 1,
            name = "Italian Navy Slim Fit Suit",
            category = "Formal Wear",
            brand = "Raymond",
            size = "L",
            color = "Navy Blue",
            purchasePrice = 4500.0,
            sellingPrice = 7999.0,
            quantity = 12,
            minStockThreshold = 5,
            supplierDetails = "Milano Fabrics Ltd, Mumbai",
            imageDrawableName = "cloth_suit_1788199060322",
            description = "Crafted with premium Italian wool blend fabric, peak lapel, tailored contour silhouette suitable for business and weddings.",
            isNewArrival = true
        ),
        ProductEntity(
            id = 2,
            name = "Emerald Silk Evening Gown",
            category = "Ethnic & Dresses",
            brand = "Zara",
            size = "M",
            color = "Emerald Green",
            purchasePrice = 3200.0,
            sellingPrice = 5499.0,
            quantity = 8,
            minStockThreshold = 5,
            supplierDetails = "Elegance Couture, Surat",
            imageDrawableName = "cloth_dress_1788199073586",
            description = "Flowing pure silk evening gown with subtle flare and pleated waist accent. Perfect for gala and celebrations.",
            isNewArrival = true
        ),
        ProductEntity(
            id = 3,
            name = "Crisp Linen Casual Shirt",
            category = "Casual Shirts",
            brand = "Allen Solly",
            size = "L",
            color = "Pure White",
            purchasePrice = 900.0,
            sellingPrice = 1899.0,
            quantity = 24,
            minStockThreshold = 6,
            supplierDetails = "Breezy Cotton Mills, Coimbatore",
            imageDrawableName = "cloth_shirt_1788199086938",
            description = "Breathable 100% natural linen button-down casual shirt with spread collar and mother-of-pearl buttons.",
            isNewArrival = true
        ),
        ProductEntity(
            id = 4,
            name = "Vintage Leather Bomber Jacket",
            category = "Outerwear",
            brand = "Woodland",
            size = "XL",
            color = "Tan Brown",
            purchasePrice = 2800.0,
            sellingPrice = 4999.0,
            quantity = 4, // Low stock!
            minStockThreshold = 5,
            supplierDetails = "Apex Leather Works, Kanpur",
            imageDrawableName = "cloth_jacket_1788199103681",
            description = "Genuine grain leather bomber jacket with ribbed cuffs, heavy brass zippers, and satin thermal inner lining.",
            isNewArrival = false
        ),
        ProductEntity(
            id = 5,
            name = "Classic 511 Slim Denim Jeans",
            category = "Denim & Pants",
            brand = "Levi's",
            size = "32",
            color = "Indigo Blue",
            purchasePrice = 1200.0,
            sellingPrice = 2499.0,
            quantity = 18,
            minStockThreshold = 5,
            supplierDetails = "Indigo Denim Corp, Ahmedabad",
            imageDrawableName = "cloth_jeans_1788199117720",
            description = "Classic stretch denim with authentic washed finish, 5-pocket styling, reinforced rivets, and comfort waist.",
            isNewArrival = true
        ),
        ProductEntity(
            id = 6,
            name = "Royal Oxford Formal Shirt",
            category = "Formal Wear",
            brand = "Raymond",
            size = "M",
            color = "Sky Blue",
            purchasePrice = 850.0,
            sellingPrice = 1699.0,
            quantity = 15,
            minStockThreshold = 5,
            supplierDetails = "Milano Fabrics Ltd, Mumbai",
            imageDrawableName = "cloth_shirt_1788199086938",
            description = "Wrinkle-resistant pinpoint Oxford cotton shirt, crisp semi-spread collar, single chest pocket.",
            isNewArrival = false
        ),
        ProductEntity(
            id = 7,
            name = "Festive Embroidered Silk Kurta",
            category = "Ethnic & Dresses",
            brand = "Manyavar",
            size = "L",
            color = "Marigold Gold",
            purchasePrice = 1400.0,
            sellingPrice = 2999.0,
            quantity = 3, // Low stock!
            minStockThreshold = 5,
            supplierDetails = "Heritage Weaves, Varanasi",
            imageDrawableName = "cloth_dress_1788199073586",
            description = "Traditional silk blend kurta with intricate resham thread embroidery on mandarin collar and placket.",
            isNewArrival = true
        ),
        ProductEntity(
            id = 8,
            name = "Urban Buffalo Plaid Shirt",
            category = "Casual Shirts",
            brand = "H&M",
            size = "L",
            color = "Crimson Red",
            purchasePrice = 750.0,
            sellingPrice = 1499.0,
            quantity = 16,
            minStockThreshold = 5,
            supplierDetails = "Modern Garments, Tirupur",
            imageDrawableName = "cloth_shirt_1788199086938",
            description = "Soft brushed flannel cotton check shirt with dual flap chest pockets and relaxed comfort fit.",
            isNewArrival = true
        )
    )

    fun getInitialCustomers(): List<CustomerEntity> = listOf(
        CustomerEntity(
            id = 1,
            name = "Rahul Sharma",
            phoneNumber = "+91 98450 12345",
            address = "12 Rosewood Apartments, Bangalore",
            notes = "Prefers Formal Wear and Raymond shirts"
        ),
        CustomerEntity(
            id = 2,
            name = "Priya Patel",
            phoneNumber = "+91 97123 45678",
            address = "Flat 4B Green Valley, Mumbai",
            notes = "Frequent festive dresses shopper"
        ),
        CustomerEntity(
            id = 3,
            name = "Amit Verma",
            phoneNumber = "+91 99234 56789",
            address = "58 Model Town, Delhi",
            notes = "Casuals and jackets enthusiast"
        ),
        CustomerEntity(
            id = 4,
            name = "Sneha Reddy",
            phoneNumber = "+91 98877 66554",
            address = "Jubilee Hills, Hyderabad",
            notes = "Wedding party bulk buyer"
        ),
        CustomerEntity(
            id = 5,
            name = "Vikram Singh",
            phoneNumber = "+91 94140 98765",
            address = "C-12 Malviya Nagar, Jaipur",
            notes = "Regular denim and shirts client"
        )
    )

    val now = System.currentTimeMillis()
    val oneDayMs = 86400000L

    fun getInitialSales(): List<SaleEntity> = listOf(
        SaleEntity(
            id = 1,
            invoiceNumber = "INV-2026-001",
            customerId = 1,
            customerName = "Rahul Sharma",
            customerPhone = "+91 98450 12345",
            subtotal = 7999.0,
            discount = 499.0,
            totalAmount = 7500.0,
            amountPaid = 5000.0,
            remainingBalance = 2500.0, // Pending
            paymentMethod = "UPI",
            date = now - (oneDayMs * 2),
            notes = "Italian Navy Suit purchased"
        ),
        SaleEntity(
            id = 2,
            invoiceNumber = "INV-2026-002",
            customerId = 2,
            customerName = "Priya Patel",
            customerPhone = "+91 97123 45678",
            subtotal = 5499.0,
            discount = 0.0,
            totalAmount = 5499.0,
            amountPaid = 5499.0,
            remainingBalance = 0.0, // Fully paid
            paymentMethod = "Card",
            date = now - (oneDayMs * 1),
            notes = "Emerald Gown"
        ),
        SaleEntity(
            id = 3,
            invoiceNumber = "INV-2026-003",
            customerId = 3,
            customerName = "Amit Verma",
            customerPhone = "+91 99234 56789",
            subtotal = 4398.0,
            discount = 398.0,
            totalAmount = 4000.0,
            amountPaid = 2500.0,
            remainingBalance = 1500.0, // Pending
            paymentMethod = "Cash",
            date = now - (oneDayMs * 3),
            notes = "Denim + Crisp Shirt"
        ),
        SaleEntity(
            id = 4,
            invoiceNumber = "INV-2026-004",
            customerId = 4,
            customerName = "Sneha Reddy",
            customerPhone = "+91 98877 66554",
            subtotal = 2999.0,
            discount = 0.0,
            totalAmount = 2999.0,
            amountPaid = 1500.0,
            remainingBalance = 1499.0, // Pending
            paymentMethod = "UPI",
            date = now,
            notes = "Festive Kurta"
        ),
        SaleEntity(
            id = 5,
            invoiceNumber = "INV-2026-005",
            customerId = 5,
            customerName = "Vikram Singh",
            customerPhone = "+91 94140 98765",
            subtotal = 3198.0,
            discount = 198.0,
            totalAmount = 3000.0,
            amountPaid = 1000.0,
            remainingBalance = 2000.0, // Pending
            paymentMethod = "Cash",
            date = now - (oneDayMs * 1),
            notes = "Formal + Plaid Shirts"
        )
    )

    fun getInitialSaleItems(): List<SaleItemEntity> = listOf(
        SaleItemEntity(
            id = 1,
            saleId = 1,
            productId = 1,
            productName = "Italian Navy Slim Fit Suit",
            size = "L",
            color = "Navy Blue",
            quantity = 1,
            unitPrice = 7999.0,
            totalPrice = 7999.0
        ),
        SaleItemEntity(
            id = 2,
            saleId = 2,
            productId = 2,
            productName = "Emerald Silk Evening Gown",
            size = "M",
            color = "Emerald Green",
            quantity = 1,
            unitPrice = 5499.0,
            totalPrice = 5499.0
        ),
        SaleItemEntity(
            id = 3,
            saleId = 3,
            productId = 5,
            productName = "Classic 511 Slim Denim Jeans",
            size = "32",
            color = "Indigo Blue",
            quantity = 1,
            unitPrice = 2499.0,
            totalPrice = 2499.0
        ),
        SaleItemEntity(
            id = 4,
            saleId = 3,
            productId = 3,
            productName = "Crisp Linen Casual Shirt",
            size = "L",
            color = "Pure White",
            quantity = 1,
            unitPrice = 1899.0,
            totalPrice = 1899.0
        ),
        SaleItemEntity(
            id = 5,
            saleId = 4,
            productId = 7,
            productName = "Festive Embroidered Silk Kurta",
            size = "L",
            color = "Marigold Gold",
            quantity = 1,
            unitPrice = 2999.0,
            totalPrice = 2999.0
        ),
        SaleItemEntity(
            id = 6,
            saleId = 5,
            productId = 6,
            productName = "Royal Oxford Formal Shirt",
            size = "M",
            color = "Sky Blue",
            quantity = 1,
            unitPrice = 1699.0,
            totalPrice = 1699.0
        ),
        SaleItemEntity(
            id = 7,
            saleId = 5,
            productId = 8,
            productName = "Urban Buffalo Plaid Shirt",
            size = "L",
            color = "Crimson Red",
            quantity = 1,
            unitPrice = 1499.0,
            totalPrice = 1499.0
        )
    )

    fun getInitialPayments(): List<PaymentRecordEntity> = listOf(
        PaymentRecordEntity(
            id = 1,
            customerId = 1,
            customerName = "Rahul Sharma",
            saleId = 1,
            itemName = "Italian Navy Slim Fit Suit",
            totalAmount = 7500.0,
            amountPaid = 5000.0,
            remainingBalance = 2500.0,
            paymentMethod = "UPI",
            date = now - (oneDayMs * 2),
            notes = "Initial payment at billing"
        ),
        PaymentRecordEntity(
            id = 2,
            customerId = 2,
            customerName = "Priya Patel",
            saleId = 2,
            itemName = "Emerald Silk Evening Gown",
            totalAmount = 5499.0,
            amountPaid = 5499.0,
            remainingBalance = 0.0,
            paymentMethod = "Card",
            date = now - (oneDayMs * 1),
            notes = "Full payment completed"
        ),
        PaymentRecordEntity(
            id = 3,
            customerId = 3,
            customerName = "Amit Verma",
            saleId = 3,
            itemName = "Denim + Crisp Shirt",
            totalAmount = 4000.0,
            amountPaid = 2500.0,
            remainingBalance = 1500.0,
            paymentMethod = "Cash",
            date = now - (oneDayMs * 3),
            notes = "Advance paid"
        ),
        PaymentRecordEntity(
            id = 4,
            customerId = 3,
            customerName = "Amit Verma",
            saleId = null,
            itemName = "Pending Balance Payment",
            totalAmount = 1500.0,
            amountPaid = 500.0,
            remainingBalance = 1000.0,
            paymentMethod = "UPI",
            date = now - (oneDayMs * 1),
            notes = "Partial balance clearance"
        ),
        PaymentRecordEntity(
            id = 5,
            customerId = 4,
            customerName = "Sneha Reddy",
            saleId = 4,
            itemName = "Festive Embroidered Silk Kurta",
            totalAmount = 2999.0,
            amountPaid = 1500.0,
            remainingBalance = 1499.0,
            paymentMethod = "UPI",
            date = now,
            notes = "Deposit received"
        ),
        PaymentRecordEntity(
            id = 6,
            customerId = 5,
            customerName = "Vikram Singh",
            saleId = 5,
            itemName = "Royal Oxford + Plaid Shirt",
            totalAmount = 3000.0,
            amountPaid = 1000.0,
            remainingBalance = 2000.0,
            paymentMethod = "Cash",
            date = now - (oneDayMs * 1),
            notes = "Initial deposit paid"
        )
    )

    fun getInitialSettings(): StoreSettingsEntity = StoreSettingsEntity(
        id = 1,
        storeName = "S V FASHION DAMBAL",
        phone = "+91 98765 43210",
        address = "Dambal",
        gstin = "GSTIN29ABCDE1234F1Z5",
        currencySymbol = "₹",
        invoiceFooter = "Thank you for choosing S V FASHION DAMBAL! Exchanges accepted within 7 days with tag intact."
    )
}
