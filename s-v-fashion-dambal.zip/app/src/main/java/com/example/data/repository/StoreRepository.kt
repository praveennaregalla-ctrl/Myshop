package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.PaymentRecordEntity
import com.example.data.local.entities.ProductEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.local.entities.SaleItemEntity
import com.example.data.local.entities.StoreSettingsEntity
import com.example.data.manager.InventoryDataManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class CustomerWithLedger(
    val customer: CustomerEntity,
    val totalPurchaseAmount: Double,
    val totalAmountPaid: Double,
    val remainingBalance: Double,
    val salesCount: Int,
    val lastTransactionDate: Long
)

class StoreRepository(
    private val database: AppDatabase,
    private val inventoryDataManager: InventoryDataManager = InventoryDataManager(database)
) {
    private val productDao = database.productDao()
    private val customerDao = database.customerDao()
    private val saleDao = database.saleDao()
    private val paymentDao = database.paymentDao()
    private val settingsDao = database.settingsDao()

    val allProducts: Flow<List<ProductEntity>> = inventoryDataManager.allProducts
    val newArrivals: Flow<List<ProductEntity>> = inventoryDataManager.newArrivals
    val lowStockProducts: Flow<List<ProductEntity>> = inventoryDataManager.lowStockProducts

    val allCustomers: Flow<List<CustomerEntity>> = customerDao.getAllCustomers()
    val allSales: Flow<List<SaleEntity>> = saleDao.getAllSales()
    val allSaleItems: Flow<List<SaleItemEntity>> = saleDao.getAllSaleItems()
    val allPayments: Flow<List<PaymentRecordEntity>> = paymentDao.getAllPayments()
    val settings: Flow<StoreSettingsEntity?> = settingsDao.getSettings()

    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existingProducts = productDao.getAllProducts().first()
        if (existingProducts.isEmpty()) {
            val initial = SampleDataProvider.getInitialProducts()
            productDao.insertProducts(initial)
            for (p in initial) {
                inventoryDataManager.saveProduct(p)
            }
        } else {
            // Attempt background sync with Firestore
            inventoryDataManager.syncWithFirestore()
        }

        val existingCustomers = customerDao.getAllCustomers().first()
        if (existingCustomers.isEmpty()) {
            customerDao.insertCustomers(SampleDataProvider.getInitialCustomers())
        }

        val existingSales = saleDao.getAllSales().first()
        if (existingSales.isEmpty()) {
            saleDao.insertSales(SampleDataProvider.getInitialSales())
            saleDao.insertSaleItems(SampleDataProvider.getInitialSaleItems())
        }

        val existingPayments = paymentDao.getAllPayments().first()
        if (existingPayments.isEmpty()) {
            paymentDao.insertPayments(SampleDataProvider.getInitialPayments())
        }

        val existingSettings = settingsDao.getSettings().first()
        if (existingSettings == null) {
            settingsDao.saveSettings(SampleDataProvider.getInitialSettings())
        }
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        productDao.deleteAllProducts()
        customerDao.deleteAllCustomers()
        saleDao.deleteAllSaleItems()
        saleDao.deleteAllSales()
        paymentDao.deleteAllPayments()
    }

    suspend fun resetToSampleData() = withContext(Dispatchers.IO) {
        clearAllData()
        val initial = SampleDataProvider.getInitialProducts()
        productDao.insertProducts(initial)
        for (p in initial) {
            inventoryDataManager.saveProduct(p)
        }
        customerDao.insertCustomers(SampleDataProvider.getInitialCustomers())
        saleDao.insertSales(SampleDataProvider.getInitialSales())
        saleDao.insertSaleItems(SampleDataProvider.getInitialSaleItems())
        paymentDao.insertPayments(SampleDataProvider.getInitialPayments())
        settingsDao.saveSettings(SampleDataProvider.getInitialSettings())
    }

    // Products & Inventory Data Manager operations
    suspend fun insertProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        inventoryDataManager.saveProduct(product)
    }

    suspend fun updateProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        inventoryDataManager.saveProduct(product)
    }

    suspend fun updateStockQuantity(productId: Long, newQuantity: Int) = withContext(Dispatchers.IO) {
        inventoryDataManager.updateStockQuantity(productId, newQuantity)
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        inventoryDataManager.deleteProduct(product)
    }

    suspend fun deleteProductById(id: Long) = withContext(Dispatchers.IO) {
        inventoryDataManager.deleteProductById(id)
    }

    suspend fun syncInventoryWithCloud() = withContext(Dispatchers.IO) {
        inventoryDataManager.syncWithFirestore()
    }

    // Customers
    suspend fun insertCustomer(customer: CustomerEntity): Long = withContext(Dispatchers.IO) {
        customerDao.insertCustomer(customer)
    }

    suspend fun addCustomerWithOpeningBalance(
        customer: CustomerEntity,
        openingBalance: Double,
        itemDescription: String = "Opening Balance / Previous Due"
    ): Long = withContext(Dispatchers.IO) {
        val custId = customerDao.insertCustomer(customer)
        if (openingBalance > 0.0) {
            val sale = SaleEntity(
                invoiceNumber = "BAL-OPEN-${System.currentTimeMillis() % 1000000}",
                customerId = custId,
                customerName = customer.name,
                customerPhone = customer.phoneNumber,
                subtotal = openingBalance,
                discount = 0.0,
                totalAmount = openingBalance,
                amountPaid = 0.0,
                remainingBalance = openingBalance,
                paymentMethod = "Due Account",
                date = System.currentTimeMillis(),
                notes = itemDescription
            )
            val saleId = saleDao.insertSale(sale)
            val saleItem = SaleItemEntity(
                saleId = saleId,
                productId = 0,
                productName = itemDescription.ifBlank { "Opening Balance / Previous Due" },
                size = "-",
                color = "-",
                quantity = 1,
                unitPrice = openingBalance,
                totalPrice = openingBalance
            )
            saleDao.insertSaleItems(listOf(saleItem))
        }
        custId
    }

    suspend fun addCustomerDueAmount(
        customerId: Long,
        customerName: String,
        customerPhone: String,
        amount: Double,
        itemDescription: String,
        quantity: Int = 1,
        unitPrice: Double = amount,
        notes: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val finalItemDesc = itemDescription.ifBlank { "Credit Cloth Purchase" }
        val sale = SaleEntity(
            invoiceNumber = "DUE-${System.currentTimeMillis() % 1000000}",
            customerId = customerId,
            customerName = customerName,
            customerPhone = customerPhone,
            subtotal = amount,
            discount = 0.0,
            totalAmount = amount,
            amountPaid = 0.0,
            remainingBalance = amount,
            paymentMethod = "Due / Credit",
            date = System.currentTimeMillis(),
            notes = if (notes.isNotBlank()) "$finalItemDesc ($notes)" else finalItemDesc
        )
        val saleId = saleDao.insertSale(sale)
        val safeQty = quantity.coerceAtLeast(1)
        val safeUnitPrice = if (unitPrice > 0.0) unitPrice else (amount / safeQty)
        val saleItem = SaleItemEntity(
            saleId = saleId,
            productId = 0,
            productName = finalItemDesc,
            size = "-",
            color = "-",
            quantity = safeQty,
            unitPrice = safeUnitPrice,
            totalPrice = amount
        )
        saleDao.insertSaleItems(listOf(saleItem))
        saleId
    }

    suspend fun updateCustomer(customer: CustomerEntity) = withContext(Dispatchers.IO) {
        customerDao.updateCustomer(customer)
    }

    suspend fun deleteCustomer(customer: CustomerEntity) = withContext(Dispatchers.IO) {
        customerDao.deleteCustomer(customer)
    }

    // Sales & POS Checkout
    suspend fun createSale(
        sale: SaleEntity,
        items: List<SaleItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        // 1. Insert Sale record
        val saleId = saleDao.insertSale(sale)

        // 2. Insert Sale items associated with saleId
        val itemsWithSaleId = items.map { it.copy(saleId = saleId) }
        saleDao.insertSaleItems(itemsWithSaleId)

        // 3. Automatically reduce stock for each product
        for (item in items) {
            productDao.reduceStock(item.productId, item.quantity)
        }

        // 4. Create PaymentRecord if amount was paid
        if (sale.amountPaid > 0) {
            val itemNamesSummary = items.joinToString(", ") { "${it.quantity}x ${it.productName}" }
            val payment = PaymentRecordEntity(
                customerId = sale.customerId,
                customerName = sale.customerName,
                saleId = saleId,
                itemName = if (itemNamesSummary.length > 50) itemNamesSummary.take(47) + "..." else itemNamesSummary,
                totalAmount = sale.totalAmount,
                amountPaid = sale.amountPaid,
                remainingBalance = sale.remainingBalance,
                paymentMethod = sale.paymentMethod,
                date = sale.date,
                notes = "Sale Invoice: ${sale.invoiceNumber}"
            )
            paymentDao.insertPayment(payment)
        }

        saleId
    }

    fun getItemsForSale(saleId: Long): Flow<List<SaleItemEntity>> {
        return saleDao.getItemsForSale(saleId)
    }

    suspend fun getItemsForSaleSync(saleId: Long): List<SaleItemEntity> = withContext(Dispatchers.IO) {
        saleDao.getItemsForSaleSync(saleId)
    }

    // Payments & Payment Book / Balance Book
    suspend fun recordCustomerPayment(
        customerId: Long,
        customerName: String,
        saleId: Long?,
        itemName: String,
        totalAmount: Double,
        amountPaid: Double,
        remainingBalance: Double,
        paymentMethod: String,
        date: Long = System.currentTimeMillis(),
        notes: String = ""
    ): Long = withContext(Dispatchers.IO) {
        val payment = PaymentRecordEntity(
            customerId = customerId,
            customerName = customerName,
            saleId = saleId,
            itemName = itemName,
            totalAmount = totalAmount,
            amountPaid = amountPaid,
            remainingBalance = remainingBalance,
            paymentMethod = paymentMethod,
            date = date,
            notes = notes
        )
        paymentDao.insertPayment(payment)
    }

    fun getPaymentsByCustomer(customerId: Long): Flow<List<PaymentRecordEntity>> {
        return paymentDao.getPaymentsByCustomer(customerId)
    }

    fun getSalesByCustomer(customerId: Long): Flow<List<SaleEntity>> {
        return saleDao.getSalesByCustomer(customerId)
    }

    suspend fun saveSettings(settings: StoreSettingsEntity) = withContext(Dispatchers.IO) {
        settingsDao.saveSettings(settings)
    }
}
