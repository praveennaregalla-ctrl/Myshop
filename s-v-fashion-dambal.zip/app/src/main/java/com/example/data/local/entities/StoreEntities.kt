package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val brand: String,
    val size: String,
    val color: String,
    val purchasePrice: Double,
    val sellingPrice: Double,
    val quantity: Int,
    val minStockThreshold: Int = 5,
    val dateAdded: Long = System.currentTimeMillis(),
    val supplierDetails: String = "",
    val imageDrawableName: String = "",
    val imageUri: String = "",
    val description: String = "",
    val isNewArrival: Boolean = true
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val address: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val customerId: Long,
    val customerName: String,
    val customerPhone: String,
    val subtotal: Double,
    val discount: Double = 0.0,
    val totalAmount: Double, // subtotal - discount
    val amountPaid: Double,
    val remainingBalance: Double, // totalAmount - amountPaid
    val paymentMethod: String, // "Cash", "UPI", "Card", "Credit"
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "sale_items")
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val size: String,
    val color: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double
)

@Entity(tableName = "payment_records")
data class PaymentRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val saleId: Long? = null,
    val itemName: String, // e.g. "Blue Shirt" or "Invoice #INV-2026-001" or "Balance Clearance"
    val totalAmount: Double,
    val amountPaid: Double,
    val remainingBalance: Double,
    val paymentMethod: String, // "Cash", "UPI", "Card", "Bank Transfer"
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "store_settings")
data class StoreSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val storeName: String = "S V FASHION DAMBAL",
    val phone: String = "+91 98765 43210",
    val address: String = "Dambal",
    val gstin: String = "GSTIN29ABCDE1234F1Z5",
    val currencySymbol: String = "₹",
    val invoiceFooter: String = "Thank you for shopping at S V FASHION DAMBAL! Visit again."
)
