package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.PaymentRecordEntity
import com.example.data.local.entities.ProductEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.local.entities.SaleItemEntity
import com.example.data.local.entities.StoreSettingsEntity
import com.example.data.repository.CustomerWithLedger
import com.example.data.repository.StoreRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class CartItem(
    val product: ProductEntity,
    val quantity: Int = 1,
    val selectedSize: String = product.size,
    val selectedColor: String = product.color
) {
    val totalPrice: Double get() = product.sellingPrice * quantity
}

data class DashboardKpis(
    val totalStockCount: Int = 0,
    val totalCustomersCount: Int = 0,
    val totalSalesRevenue: Double = 0.0,
    val totalMoneyReceived: Double = 0.0,
    val totalPendingBalance: Double = 0.0,
    val lowStockCount: Int = 0,
    val newArrivalsCount: Int = 0
)

class StoreViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = StoreRepository(database)

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    val products: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val newArrivals: StateFlow<List<ProductEntity>> = repository.newArrivals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<ProductEntity>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<SaleEntity>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val saleItems: StateFlow<List<SaleItemEntity>> = repository.allSaleItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<PaymentRecordEntity>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<StoreSettingsEntity?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Derived Customer Ledgers
    val customerLedgers: StateFlow<List<CustomerWithLedger>> = combine(
        customers,
        sales,
        payments
    ) { custList, saleList, payList ->
        custList.map { customer ->
            val customerSales = saleList.filter { it.customerId == customer.id }
            val customerPayments = payList.filter { it.customerId == customer.id }

            val totalPurchases = customerSales.sumOf { it.totalAmount }
            val totalPaid = customerPayments.sumOf { it.amountPaid }
            val remaining = (totalPurchases - totalPaid).coerceAtLeast(0.0)

            val lastDate = (customerSales.map { it.date } + customerPayments.map { it.date })
                .maxOrNull() ?: customer.createdAt

            CustomerWithLedger(
                customer = customer,
                totalPurchaseAmount = totalPurchases,
                totalAmountPaid = totalPaid,
                remainingBalance = remaining,
                salesCount = customerSales.size,
                lastTransactionDate = lastDate
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dashboard KPIs
    val dashboardKpis: StateFlow<DashboardKpis> = combine(
        products,
        customers,
        sales,
        payments
    ) { prodList, custList, saleList, payList ->
        val totalStock = prodList.sumOf { it.quantity }
        val totalCust = custList.size
        val totalRevenue = saleList.sumOf { it.totalAmount }
        val totalReceived = payList.sumOf { it.amountPaid }
        val totalPending = (totalRevenue - totalReceived).coerceAtLeast(0.0)
        val lowStock = prodList.count { it.quantity <= it.minStockThreshold }
        val newArr = prodList.count { it.isNewArrival }

        DashboardKpis(
            totalStockCount = totalStock,
            totalCustomersCount = totalCust,
            totalSalesRevenue = totalRevenue,
            totalMoneyReceived = totalReceived,
            totalPendingBalance = totalPending,
            lowStockCount = lowStock,
            newArrivalsCount = newArr
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardKpis())

    // ==========================================
    // Cart / POS State
    // ==========================================
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems

    private val _selectedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val selectedCustomer: StateFlow<CustomerEntity?> = _selectedCustomer

    private val _cartDiscount = MutableStateFlow(0.0)
    val cartDiscount: StateFlow<Double> = _cartDiscount

    private val _cartPaidAmount = MutableStateFlow<Double?>(null)
    val cartPaidAmount: StateFlow<Double?> = _cartPaidAmount

    private val _cartPaymentMethod = MutableStateFlow("Cash")
    val cartPaymentMethod: StateFlow<String> = _cartPaymentMethod

    private val _cartNotes = MutableStateFlow("")
    val cartNotes: StateFlow<String> = _cartNotes

    // Last generated invoice for modal preview
    private val _lastGeneratedSale = MutableStateFlow<SaleEntity?>(null)
    val lastGeneratedSale: StateFlow<SaleEntity?> = _lastGeneratedSale

    private val _lastGeneratedSaleItems = MutableStateFlow<List<SaleItemEntity>>(emptyList())
    val lastGeneratedSaleItems: StateFlow<List<SaleItemEntity>> = _lastGeneratedSaleItems

    fun selectCustomer(customer: CustomerEntity?) {
        _selectedCustomer.value = customer
    }

    fun addToCart(product: ProductEntity, size: String = product.size, color: String = product.color) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id && it.selectedSize == size && it.selectedColor == color }
        if (index >= 0) {
            val existing = current[index]
            if (existing.quantity < product.quantity) {
                current[index] = existing.copy(quantity = existing.quantity + 1)
            }
        } else {
            if (product.quantity > 0) {
                current.add(CartItem(product = product, quantity = 1, selectedSize = size, selectedColor = color))
            }
        }
        _cartItems.value = current
    }

    fun updateCartItemQuantity(item: CartItem, newQty: Int) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == item.product.id && it.selectedSize == item.selectedSize }
        if (index >= 0) {
            if (newQty <= 0) {
                current.removeAt(index)
            } else if (newQty <= item.product.quantity) {
                current[index] = item.copy(quantity = newQty)
            }
        }
        _cartItems.value = current
    }

    fun removeFromCart(item: CartItem) {
        val current = _cartItems.value.toMutableList()
        current.removeAll { it.product.id == item.product.id && it.selectedSize == item.selectedSize }
        _cartItems.value = current
    }

    fun setCartDiscount(discount: Double) {
        _cartDiscount.value = discount.coerceAtLeast(0.0)
    }

    fun setCartPaidAmount(amount: Double?) {
        _cartPaidAmount.value = amount
    }

    fun setCartPaymentMethod(method: String) {
        _cartPaymentMethod.value = method
    }

    fun setCartNotes(notes: String) {
        _cartNotes.value = notes
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _cartDiscount.value = 0.0
        _cartPaidAmount.value = null
        _cartNotes.value = ""
    }

    fun checkoutSale(onComplete: (SaleEntity, List<SaleItemEntity>) -> Unit) {
        val items = _cartItems.value
        if (items.isEmpty()) return

        val customer = _selectedCustomer.value ?: CustomerEntity(
            id = 0,
            name = "Walk-in Customer",
            phoneNumber = "+91 90000 00000"
        )

        viewModelScope.launch {
            var custId = customer.id
            var custName = customer.name
            var custPhone = customer.phoneNumber

            if (custId == 0L) {
                // Insert walk-in customer if needed
                custId = repository.insertCustomer(customer)
            }

            val subtotal = items.sumOf { it.totalPrice }
            val discount = _cartDiscount.value
            val netTotal = (subtotal - discount).coerceAtLeast(0.0)
            val paid = _cartPaidAmount.value ?: netTotal
            val balance = (netTotal - paid).coerceAtLeast(0.0)

            val invoiceNo = "INV-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())}"

            val sale = SaleEntity(
                invoiceNumber = invoiceNo,
                customerId = custId,
                customerName = custName,
                customerPhone = custPhone,
                subtotal = subtotal,
                discount = discount,
                totalAmount = netTotal,
                amountPaid = paid,
                remainingBalance = balance,
                paymentMethod = _cartPaymentMethod.value,
                date = System.currentTimeMillis(),
                notes = _cartNotes.value
            )

            val saleItemsList = items.map { cartItem ->
                SaleItemEntity(
                    saleId = 0,
                    productId = cartItem.product.id,
                    productName = cartItem.product.name,
                    size = cartItem.selectedSize,
                    color = cartItem.selectedColor,
                    quantity = cartItem.quantity,
                    unitPrice = cartItem.product.sellingPrice,
                    totalPrice = cartItem.totalPrice
                )
            }

            val saleId = repository.createSale(sale, saleItemsList)
            val finalSale = sale.copy(id = saleId)
            val finalItems = saleItemsList.map { it.copy(saleId = saleId) }

            _lastGeneratedSale.value = finalSale
            _lastGeneratedSaleItems.value = finalItems
            clearCart()
            onComplete(finalSale, finalItems)
        }
    }

    fun dismissInvoiceModal() {
        _lastGeneratedSale.value = null
        _lastGeneratedSaleItems.value = emptyList()
    }

    fun showExistingInvoice(sale: SaleEntity) {
        viewModelScope.launch {
            val items = repository.getItemsForSaleSync(sale.id)
            _lastGeneratedSale.value = sale
            _lastGeneratedSaleItems.value = items
        }
    }

    // ==========================================
    // Inventory Actions
    // ==========================================
    fun addProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.insertProduct(product)
        }
    }

    fun updateProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun updateStockQuantity(productId: Long, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateStockQuantity(productId, newQuantity)
        }
    }

    fun syncInventoryWithCloud() {
        viewModelScope.launch {
            repository.syncInventoryWithCloud()
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    // ==========================================
    // Customer Actions
    // ==========================================
    fun addCustomer(customer: CustomerEntity, onAdded: ((CustomerEntity) -> Unit)? = null) {
        viewModelScope.launch {
            val id = repository.insertCustomer(customer)
            onAdded?.invoke(customer.copy(id = id))
        }
    }

    fun addCustomerWithBalance(
        customer: CustomerEntity,
        openingBalance: Double,
        itemDescription: String = "Opening Balance / Previous Due",
        onAdded: ((CustomerEntity) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val id = repository.addCustomerWithOpeningBalance(customer, openingBalance, itemDescription)
            onAdded?.invoke(customer.copy(id = id))
        }
    }

    fun addCustomerDueAmount(
        customerId: Long,
        customerName: String,
        customerPhone: String,
        amount: Double,
        itemDescription: String,
        quantity: Int = 1,
        unitPrice: Double = amount,
        notes: String = ""
    ) {
        viewModelScope.launch {
            repository.addCustomerDueAmount(
                customerId = customerId,
                customerName = customerName,
                customerPhone = customerPhone,
                amount = amount,
                itemDescription = itemDescription,
                quantity = quantity,
                unitPrice = unitPrice,
                notes = notes
            )
        }
    }

    fun updateCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    // ==========================================
    // Payment Book & Balance Book Actions
    // ==========================================
    val selectedPaymentDate = MutableStateFlow(Calendar.getInstance().timeInMillis)

    fun setSelectedPaymentDate(timestamp: Long) {
        selectedPaymentDate.value = timestamp
    }

    fun recordPayment(
        customerId: Long,
        customerName: String,
        saleId: Long?,
        itemName: String,
        totalAmount: Double,
        amountPaid: Double,
        remainingBalance: Double,
        paymentMethod: String,
        date: Long = System.currentTimeMillis(),
        notes: String = ""
    ) {
        viewModelScope.launch {
            repository.recordCustomerPayment(
                customerId = customerId,
                customerName = customerName,
                saleId = saleId,
                itemName = itemName,
                totalAmount = totalAmount,
                amountPaid = amountPaid,
                remainingBalance = remainingBalance,
                paymentMethod = paymentMethod,
                date = date,
                notes = notes
            )
        }
    }

    // Settings
    fun updateSettings(settings: StoreSettingsEntity) {
        viewModelScope.launch {
            repository.saveSettings(settings)
        }
    }

    fun clearAllStoreData() {
        viewModelScope.launch {
            repository.clearAllData()
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetToSampleData()
        }
    }
}
