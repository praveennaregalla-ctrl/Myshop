package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberNew
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.ProductEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreGoldContainer
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreOnGoldContainer
import com.example.viewmodel.StoreViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewArrivalsScreen(
    viewModel: StoreViewModel,
    onNavigateToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val newArrivals by viewModel.newArrivals.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var selectedCategory by remember { mutableStateOf("All") }
    var selectedProductForDetails by remember { mutableStateOf<ProductEntity?>(null) }

    val categories = listOf("All") + newArrivals.map { it.category }.distinct()

    val filteredArrivals = if (selectedCategory == "All") {
        newArrivals
    } else {
        newArrivals.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("new_arrivals_grid"),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hero Banner
            item(span = { GridItemSpan(maxLineSpan) }) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = StoreGoldContainer),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(StoreGold.copy(alpha = 0.2f), StoreGoldContainer)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StoreGold
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.FiberNew, contentDescription = null, tint = Color.Black, modifier = Modifier.padding(end = 4.dp))
                                        Text(
                                            text = "Fresh Stock",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Latest Fashion Arrivals",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = StoreOnGoldContainer
                                )
                                Text(
                                    text = "Exclusive seasonal designs added recently.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StoreOnGoldContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }

            // Category Filter Row
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StoreIndigo,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            if (filteredArrivals.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyStateView(
                        title = "No New Arrivals",
                        message = "Mark clothing items as 'New Arrival' in the Inventory section to display them here.",
                        icon = Icons.Outlined.Checkroom
                    )
                }
            } else {
                items(filteredArrivals, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        currency = currency,
                        onDetailsClick = { selectedProductForDetails = product },
                        onAddToCart = { viewModel.addToCart(product) }
                    )
                }
            }
        }
    }

    selectedProductForDetails?.let { product ->
        ProductDetailsBottomSheet(
            product = product,
            currency = currency,
            onDismiss = { selectedProductForDetails = null },
            onAddToCart = { size, color, qty ->
                for (i in 1..qty) {
                    viewModel.addToCart(product, size, color)
                }
                selectedProductForDetails = null
            }
        )
    }
}
