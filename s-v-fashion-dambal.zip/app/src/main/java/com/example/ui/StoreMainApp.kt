package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FiberNew
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.ProductEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.repository.CustomerWithLedger
import com.example.ui.components.InvoiceDialog
import com.example.ui.screens.BalanceBookScreen
import com.example.ui.screens.CustomerDetailBottomSheet
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.NewArrivalsScreen
import com.example.ui.screens.PaymentBookScreen
import com.example.ui.screens.ProductDetailsBottomSheet
import com.example.ui.screens.ProductsCatalogScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SalesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreIndigoDark
import com.example.viewmodel.StoreViewModel
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String, val icon: ImageVector, val navLabel: String = title) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard, "Dashboard")
    object Products : Screen("products", "Store", Icons.Default.Checkroom, "Store")
    object NewArrivals : Screen("new_arrivals", "New Arrivals", Icons.Default.FiberNew, "New")
    object Sales : Screen("sales", "Sale (POS)", Icons.Default.PointOfSale, "Sale")
    object Inventory : Screen("inventory", "Inventory", Icons.Outlined.Inventory2, "Inventory")
    object PaymentBook : Screen("payment_book", "Payment Book", Icons.Default.MonetizationOn, "Pay Book")
    object BalanceBook : Screen("balance_book", "Balance Book", Icons.Default.AccountBalanceWallet, "Balance")
    object Customers : Screen("customers", "Customers", Icons.Default.People, "Customers")
    object Reports : Screen("reports", "Analytics", Icons.Default.Assessment, "Analytics")
    object Settings : Screen("settings", "Settings", Icons.Default.Settings, "Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreMainApp(
    viewModel: StoreViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val lastGeneratedSale by viewModel.lastGeneratedSale.collectAsStateWithLifecycle()
    val lastGeneratedSaleItems by viewModel.lastGeneratedSaleItems.collectAsStateWithLifecycle()
    val totalCartCount = cartItems.sumOf { it.quantity }

    var selectedProductForSheet by remember { mutableStateOf<ProductEntity?>(null) }
    var selectedCustomerForLedger by remember { mutableStateOf<CustomerWithLedger?>(null) }

    val bottomNavScreens = listOf(
        Screen.Dashboard,
        Screen.Products,
        Screen.NewArrivals,
        Screen.Sales,
        Screen.Inventory
    )

    val drawerScreens = listOf(
        Screen.Dashboard,
        Screen.Products,
        Screen.NewArrivals,
        Screen.Sales,
        Screen.Inventory,
        Screen.PaymentBook,
        Screen.BalanceBook,
        Screen.Customers,
        Screen.Reports,
        Screen.Settings
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                // Store Drawer Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(StoreIndigoDark, StoreIndigo)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .border(2.dp, StoreGold, CircleShape)
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.sv_fashion_logo_1788203171560),
                                contentDescription = "S V FASHION DAMBAL Logo",
                                modifier = Modifier.size(64.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = settings?.storeName ?: "S V FASHION DAMBAL",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Premium Cloth & Fashion • Dambal",
                            style = MaterialTheme.typography.bodySmall,
                            color = StoreGold.copy(alpha = 0.9f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                drawerScreens.forEach { screen ->
                    val isSelected = currentScreen.route == screen.route
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title,
                                tint = if (isSelected) StoreIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        selected = isSelected,
                        onClick = {
                            currentScreen = screen
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = StoreIndigo.copy(alpha = 0.12f),
                            selectedTextColor = StoreIndigo
                        )
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = currentScreen.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            modifier = Modifier.testTag("drawer_menu_button")
                        ) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        // Cart / POS Icon with Badge
                        IconButton(
                            onClick = { currentScreen = Screen.Sales },
                            modifier = Modifier.testTag("top_bar_cart_btn")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (totalCartCount > 0) {
                                        Badge(containerColor = StoreGold, contentColor = Color.Black) {
                                            Text("$totalCartCount", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ShoppingBag,
                                    contentDescription = "Cart / POS",
                                    tint = if (totalCartCount > 0) StoreIndigo else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    bottomNavScreens.forEach { screen ->
                        val isSelected = currentScreen.route == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = screen },
                            icon = {
                                if (screen == Screen.Sales && totalCartCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge(containerColor = StoreGold, contentColor = Color.Black) {
                                                Text("$totalCartCount")
                                            }
                                        }
                                    ) {
                                        Icon(imageVector = screen.icon, contentDescription = screen.title)
                                    }
                                } else {
                                    Icon(imageVector = screen.icon, contentDescription = screen.title)
                                }
                            },
                            label = {
                                Text(
                                    text = screen.navLabel,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    textAlign = TextAlign.Center,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = StoreIndigo,
                                selectedTextColor = StoreIndigo,
                                indicatorColor = StoreIndigo.copy(alpha = 0.12f)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    Screen.Dashboard -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToSales = { currentScreen = Screen.Sales },
                        onNavigateToInventory = { currentScreen = Screen.Inventory },
                        onNavigateToPaymentBook = { currentScreen = Screen.PaymentBook },
                        onNavigateToBalanceBook = { currentScreen = Screen.BalanceBook },
                        onNavigateToProducts = { currentScreen = Screen.Products },
                        onNavigateToNewArrivals = { currentScreen = Screen.NewArrivals },
                        onSelectProduct = { selectedProductForSheet = it },
                        onViewSaleInvoice = { viewModel.showExistingInvoice(it) }
                    )
                    Screen.Products -> ProductsCatalogScreen(
                        viewModel = viewModel,
                        onNavigateToCart = { currentScreen = Screen.Sales }
                    )
                    Screen.NewArrivals -> NewArrivalsScreen(
                        viewModel = viewModel,
                        onNavigateToCart = { currentScreen = Screen.Sales }
                    )
                    Screen.Sales -> SalesScreen(
                        viewModel = viewModel,
                        onViewSaleInvoice = { viewModel.showExistingInvoice(it) }
                    )
                    Screen.Inventory -> InventoryScreen(
                        viewModel = viewModel
                    )
                    Screen.PaymentBook -> PaymentBookScreen(
                        viewModel = viewModel
                    )
                    Screen.BalanceBook -> BalanceBookScreen(
                        viewModel = viewModel,
                        onViewCustomerLedger = { selectedCustomerForLedger = it }
                    )
                    Screen.Customers -> CustomersScreen(
                        viewModel = viewModel,
                        onViewSaleInvoice = { viewModel.showExistingInvoice(it) }
                    )
                    Screen.Reports -> ReportsScreen(
                        viewModel = viewModel
                    )
                    Screen.Settings -> SettingsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Modal Sheet for Product Details
    selectedProductForSheet?.let { product ->
        val currency = settings?.currencySymbol ?: "₹"
        ProductDetailsBottomSheet(
            product = product,
            currency = currency,
            onDismiss = { selectedProductForSheet = null },
            onAddToCart = { size, color, qty ->
                for (i in 1..qty) {
                    viewModel.addToCart(product, size, color)
                }
                selectedProductForSheet = null
            }
        )
    }

    // Modal Sheet for Customer Ledger
    selectedCustomerForLedger?.let { ledger ->
        val currency = settings?.currencySymbol ?: "₹"
        CustomerDetailBottomSheet(
            ledger = ledger,
            viewModel = viewModel,
            currency = currency,
            onDismiss = { selectedCustomerForLedger = null },
            onViewInvoice = { viewModel.showExistingInvoice(it) }
        )
    }

    // Global Modal Dialog for Generated / Viewed Invoice
    lastGeneratedSale?.let { sale ->
        InvoiceDialog(
            sale = sale,
            items = lastGeneratedSaleItems,
            settings = settings,
            onDismiss = { viewModel.dismissInvoiceModal() }
        )
    }
}
