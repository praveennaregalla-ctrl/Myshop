package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.ProductEntity
import com.example.data.local.entities.SaleEntity
import com.example.ui.components.ProductImageDisplay
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.components.StockBadge
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreIndigoDark
import com.example.ui.theme.StoreRose
import com.example.viewmodel.StoreViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: StoreViewModel,
    onNavigateToSales: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onNavigateToPaymentBook: () -> Unit,
    onNavigateToBalanceBook: () -> Unit,
    onNavigateToProducts: () -> Unit,
    onNavigateToNewArrivals: () -> Unit,
    onSelectProduct: (ProductEntity) -> Unit,
    onViewSaleInvoice: (SaleEntity) -> Unit
) {
    val kpis by viewModel.dashboardKpis.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val newArrivals by viewModel.newArrivals.collectAsStateWithLifecycle()
    val lowStockProducts by viewModel.lowStockProducts.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Store Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StoreIndigoDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(StoreIndigoDark, StoreIndigo)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, StoreGold, CircleShape)
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.sv_fashion_logo_1788203171560),
                                        contentDescription = "S V FASHION DAMBAL Logo",
                                        modifier = Modifier.size(54.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = settings?.storeName ?: "S V FASHION DAMBAL",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Premium Cloth & Fashion • Dambal",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = StoreGold.copy(alpha = 0.9f)
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = StoreGold.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "Active",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = StoreGold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick Action Buttons
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onNavigateToSales,
                                    colors = ButtonDefaults.buttonColors(containerColor = StoreGold),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("quick_new_sale_btn")
                                ) {
                                    Icon(imageVector = Icons.Default.PointOfSale, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("New Sale", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 14.sp)
                                }
                                Button(
                                    onClick = onNavigateToPaymentBook,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("quick_payment_book_btn")
                                ) {
                                    Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pay Book", fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 14.sp)
                                }
                            }

                            // Balance Book bar placed below New Sale and Pay Book
                            Button(
                                onClick = onNavigateToBalanceBook,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("quick_balance_book_btn")
                            ) {
                                Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = StoreGold, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Balance Book (Customer Ledgers & Dues)",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Key Business Metrics (Grid)
        item {
            Text(
                text = "Store Overview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Row 1
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Items In Stock",
                    value = "${kpis.totalStockCount} pcs",
                    subtitle = "${products.size} unique styles",
                    icon = Icons.Outlined.Inventory2,
                    accentColor = StoreIndigo,
                    onClick = onNavigateToInventory,
                    modifier = Modifier.weight(1f).testTag("kpi_stock")
                )
                StatCard(
                    title = "Total Customers",
                    value = "${kpis.totalCustomersCount}",
                    subtitle = "Registered accounts",
                    icon = Icons.Default.People,
                    accentColor = StoreEmerald,
                    modifier = Modifier.weight(1f).testTag("kpi_customers")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Sales",
                    value = formatCurrency(kpis.totalSalesRevenue, currency),
                    subtitle = "${sales.size} completed orders",
                    icon = Icons.Default.TrendingUp,
                    accentColor = StoreIndigo,
                    onClick = onNavigateToSales,
                    modifier = Modifier.weight(1f).testTag("kpi_sales")
                )
                StatCard(
                    title = "Money Received",
                    value = formatCurrency(kpis.totalMoneyReceived, currency),
                    subtitle = "Cash & UPI collected",
                    icon = Icons.Default.MonetizationOn,
                    accentColor = StoreEmerald,
                    onClick = onNavigateToPaymentBook,
                    modifier = Modifier.weight(1f).testTag("kpi_received")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 3 (Pending Balance & Low Stock Alert)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Pending Balance",
                    value = formatCurrency(kpis.totalPendingBalance, currency),
                    subtitle = "To collect from ledger",
                    icon = Icons.Default.AccountBalanceWallet,
                    accentColor = if (kpis.totalPendingBalance > 0) StoreRose else StoreEmerald,
                    onClick = onNavigateToBalanceBook,
                    modifier = Modifier.weight(1f).testTag("kpi_pending")
                )
                StatCard(
                    title = "Low Stock Alerts",
                    value = "${kpis.lowStockCount} items",
                    subtitle = if (kpis.lowStockCount > 0) "Needs restock!" else "Stock healthy",
                    icon = Icons.Default.WarningAmber,
                    accentColor = if (kpis.lowStockCount > 0) StoreGold else StoreEmerald,
                    onClick = onNavigateToInventory,
                    modifier = Modifier.weight(1f).testTag("kpi_low_stock")
                )
            }
        }

        // Low Stock Urgent Alert Banner (if any)
        if (lowStockProducts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToInventory() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(StoreRose.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = StoreRose,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Low Stock Alert (${lowStockProducts.size} Items)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = lowStockProducts.joinToString(", ") { "${it.name} (${it.quantity} left)" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Recently Added Clothes (New Arrivals Carousel)
        item {
            SectionHeader(
                title = "New Arrivals",
                subtitle = "Recently added clothes to store",
                actionLabel = "View All",
                onActionClick = onNavigateToNewArrivals
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(newArrivals) { product ->
                    Card(
                        modifier = Modifier
                            .width(160.dp)
                            .clickable { onSelectProduct(product) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column {
                            ProductImageDisplay(
                                drawableName = product.imageDrawableName,
                                imageUri = product.imageUri,
                                contentDescription = product.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                            )
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = product.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = product.brand,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = formatCurrency(product.sellingPrice, currency),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = StoreIndigo
                                    )
                                    StockBadge(quantity = product.quantity, minThreshold = product.minStockThreshold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent Customer Transactions / Sales
        item {
            SectionHeader(
                title = "Recent Transactions",
                subtitle = "Recent customer billing and payments",
                actionLabel = "View Sales",
                onActionClick = onNavigateToSales
            )

            val recentSales = sales.take(5)
            if (recentSales.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Text(
                        text = "No sales recorded yet. Tap 'New Sale' to create your first invoice.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        recentSales.forEachIndexed { index, sale ->
                            val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onViewSaleInvoice(sale) }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(StoreIndigo.copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ReceiptLong,
                                            contentDescription = null,
                                            tint = StoreIndigo,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = sale.customerName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${sale.invoiceNumber} • ${dateFormat.format(Date(sale.date))}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = formatCurrency(sale.totalAmount, currency),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = StoreIndigo
                                    )
                                    if (sale.remainingBalance > 0) {
                                        Text(
                                            text = "Due: ${formatCurrency(sale.remainingBalance, currency)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StoreRose,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Text(
                                            text = "Paid (${sale.paymentMethod})",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StoreEmerald,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                            if (index < recentSales.size - 1) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
