package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreRose
import com.example.viewmodel.StoreViewModel

@Composable
fun ReportsScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val saleItems by viewModel.saleItems.collectAsStateWithLifecycle()
    val customerLedgers by viewModel.customerLedgers.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var selectedTimeframe by remember { mutableIntStateOf(0) } // 0: All Time, 1: Inventory Analytics, 2: Customer Debt

    val totalRevenue = sales.sumOf { it.totalAmount }
    val totalCollected = payments.sumOf { it.amountPaid }
    val totalPending = customerLedgers.sumOf { it.remainingBalance }

    // Inventory Cost vs Selling Worth
    val totalInventoryCost = products.sumOf { it.purchasePrice * it.quantity }
    val totalInventoryRetail = products.sumOf { it.sellingPrice * it.quantity }
    val projectedGrossProfit = totalInventoryRetail - totalInventoryCost

    // Grouping by category
    val categoryCounts = products.groupBy { it.category }.mapValues { it.value.sumOf { p -> p.quantity } }
    val categoryColors = listOf(StoreIndigo, StoreGold, StoreEmerald, StoreRose, Color(0xFF8E24AA), Color(0xFF00897B))

    // Top selling items from saleItems
    val topSelling = saleItems.groupBy { it.productName }
        .map { (name, itemsList) ->
            val totalQty = itemsList.sumOf { it.quantity }
            val totalSales = itemsList.sumOf { it.totalPrice }
            Triple(name, totalQty, totalSales)
        }
        .sortedByDescending { it.second }
        .take(5)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("reports_screen"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Store Analytics & Reports",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Sales revenue, inventory valuation, and customer credit ledger",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Summary Financial Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Sales",
                    value = formatCurrency(totalRevenue, currency),
                    subtitle = "${sales.size} Bills issued",
                    icon = Icons.Default.TrendingUp,
                    accentColor = StoreIndigo,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Cash Collected",
                    value = formatCurrency(totalCollected, currency),
                    subtitle = "Realized income",
                    icon = Icons.Default.MonetizationOn,
                    accentColor = StoreEmerald,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Outstanding Balance",
                    value = formatCurrency(totalPending, currency),
                    subtitle = "Customer credit",
                    icon = Icons.Default.AccountBalanceWallet,
                    accentColor = if (totalPending > 0) StoreRose else StoreEmerald,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Stock Value",
                    value = formatCurrency(totalInventoryRetail, currency),
                    subtitle = "At retail pricing",
                    icon = Icons.Default.Checkroom,
                    accentColor = StoreGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Inventory Valuation & Profitability Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Stock Valuation & Margin Analysis",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Total Stock Cost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = formatCurrency(totalInventoryCost, currency), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Retail Valuation", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = formatCurrency(totalInventoryRetail, currency), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = StoreIndigo)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Gross Profit Margin", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = formatCurrency(projectedGrossProfit, currency), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StoreEmerald)
                        }
                    }
                }
            }
        }

        // Category Stock Distribution Chart
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Stock Distribution by Category",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val totalUnits = categoryCounts.values.sum().coerceAtLeast(1)

                    // Visual Progress Bar Breakdown
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        categoryCounts.entries.forEachIndexed { index, entry ->
                            val color = categoryColors[index % categoryColors.size]
                            val weight = entry.value.toFloat() / totalUnits
                            if (weight > 0f) {
                                Box(
                                    modifier = Modifier
                                        .weight(weight)
                                        .height(16.dp)
                                        .background(color)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Legend
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        categoryCounts.entries.forEachIndexed { index, entry ->
                            val color = categoryColors[index % categoryColors.size]
                            val percentage = (entry.value * 100) / totalUnits
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = entry.key, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    text = "${entry.value} pcs ($percentage%)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top Selling Clothing Items
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Top Selling Clothing Styles",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (topSelling.isEmpty()) {
                        Text(
                            text = "No sales items recorded yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        topSelling.forEachIndexed { idx, (itemName, qty, revenue) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = StoreIndigo.copy(alpha = 0.1f)
                                    ) {
                                        Text(
                                            text = "#${idx + 1}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = StoreIndigo,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(text = itemName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                        Text(text = "$qty units sold", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Text(text = formatCurrency(revenue, currency), fontWeight = FontWeight.Bold, color = StoreIndigo)
                            }
                            if (idx < topSelling.size - 1) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
