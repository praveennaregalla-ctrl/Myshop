package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = StoreIndigoLight,
    onPrimary = Color.White,
    primaryContainer = StoreIndigo,
    onPrimaryContainer = StoreIndigoContainer,
    secondary = StoreGoldLight,
    onSecondary = Color.Black,
    secondaryContainer = StoreGold,
    onSecondaryContainer = StoreGoldContainer,
    tertiary = StoreEmerald,
    onTertiary = Color.White,
    background = StoreSurfaceDark,
    onBackground = StoreTextPrimaryDark,
    surface = StoreSurfaceCardDark,
    onSurface = StoreTextPrimaryDark,
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = StoreTextSecondaryDark,
    outline = StoreBorderDark,
    error = StoreRose,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = StoreIndigo,
    onPrimary = Color.White,
    primaryContainer = StoreIndigoContainer,
    onPrimaryContainer = StoreOnIndigoContainer,
    secondary = StoreGold,
    onSecondary = Color.White,
    secondaryContainer = StoreGoldContainer,
    onSecondaryContainer = StoreOnGoldContainer,
    tertiary = StoreEmerald,
    onTertiary = Color.White,
    background = StoreSurfaceLight,
    onBackground = StoreTextPrimary,
    surface = StoreSurfaceCardLight,
    onSurface = StoreTextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = StoreTextSecondary,
    outline = StoreBorderLight,
    error = StoreRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep bespoke luxury theme consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

