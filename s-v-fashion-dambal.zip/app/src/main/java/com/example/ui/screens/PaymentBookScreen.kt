package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.PaymentRecordEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreRose
import com.example.viewmodel.StoreViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentBookScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var selectedCalendarTimestamp by remember { mutableStateOf(Calendar.getInstance().timeInMillis) }
    var filterAllDates by remember { mutableStateOf(false) }
    var showRecordPaymentDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val calendar = Calendar.getInstance().apply { timeInMillis = selectedCalendarTimestamp }

    val dayFormat = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale.getDefault())
    val selectedDayText = dayFormat.format(Date(selectedCalendarTimestamp))

    // Helper to check if two timestamps are on the same calendar day
    fun isSameDay(t1: Long, t2: Long): Boolean {
        val c1 = Calendar.getInstance().apply { timeInMillis = t1 }
        val c2 = Calendar.getInstance().apply { timeInMillis = t2 }
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
                c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }

    val displayPayments = if (filterAllDates) {
        payments
    } else {
        payments.filter { isSameDay(it.date, selectedCalendarTimestamp) }
    }

    val dailyTotalCollected = displayPayments.sumOf { it.amountPaid }

    // Breakdown by payment method
    val cashSum = displayPayments.filter { it.paymentMethod.equals("Cash", ignoreCase = true) }.sumOf { it.amountPaid }
    val upiSum = displayPayments.filter { it.paymentMethod.equals("UPI", ignoreCase = true) }.sumOf { it.amountPaid }
    val cardSum = displayPayments.filter { it.paymentMethod.equals("Card", ignoreCase = true) }.sumOf { it.amountPaid }
    val otherSum = (dailyTotalCollected - cashSum - upiSum - cardSum).coerceAtLeast(0.0)

    Box(modifier = modifier.fillMaxSize().testTag("payment_book_screen")) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Calendar Date Selector Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    val c = Calendar.getInstance().apply { timeInMillis = selectedCalendarTimestamp }
                                    c.add(Calendar.DAY_OF_MONTH, -1)
                                    selectedCalendarTimestamp = c.timeInMillis
                                    filterAllDates = false
                                }
                            ) {
                                Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Prev Day")
                            }

                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        val y = calendar.get(Calendar.YEAR)
                                        val m = calendar.get(Calendar.MONTH)
                                        val d = calendar.get(Calendar.DAY_OF_MONTH)
                                        DatePickerDialog(context, { _, year, month, dayOfMonth ->
                                            val newCal = Calendar.getInstance().apply {
                                                set(year, month, dayOfMonth)
                                            }
                                            selectedCalendarTimestamp = newCal.timeInMillis
                                            filterAllDates = false
                                        }, y, m, d).show()
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "Pick Date",
                                    tint = StoreIndigo,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (filterAllDates) "All Dates" else selectedDayText,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = {
                                    val c = Calendar.getInstance().apply { timeInMillis = selectedCalendarTimestamp }
                                    c.add(Calendar.DAY_OF_MONTH, 1)
                                    selectedCalendarTimestamp = c.timeInMillis
                                    filterAllDates = false
                                }
                            ) {
                                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next Day")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            TextButton(onClick = {
                                selectedCalendarTimestamp = Calendar.getInstance().timeInMillis
                                filterAllDates = false
                            }) {
                                Text("Today", fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = { filterAllDates = !filterAllDates }) {
                                Text(if (filterAllDates) "Show Selected Day" else "Show All Entries")
                            }
                        }
                    }
                }
            }

            // Daily Summary KPI Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StoreEmerald.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (filterAllDates) "Total Payments Received (All Time)" else "Money Received On Selected Date",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = formatCurrency(dailyTotalCollected, currency),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = StoreEmerald
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(StoreEmerald),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = StoreEmerald.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Method Breakdown
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = StoreEmerald, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Cash: ${formatCurrency(cashSum, currency)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.QrCode2, contentDescription = null, tint = StoreIndigo, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("UPI: ${formatCurrency(upiSum, currency)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = StoreGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Card: ${formatCurrency(cardSum, currency)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Payment Entries (${displayPayments.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (displayPayments.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No payments recorded for this date",
                        message = "Tap 'Record Payment' to enter money received from customers.",
                        icon = Icons.Outlined.AccountBalanceWallet
                    )
                }
            } else {
                items(displayPayments, key = { it.id }) { payment ->
                    PaymentEntryCard(payment = payment, currency = currency)
                }
            }
        }

        // Record Payment FAB
        FloatingActionButton(
            onClick = { showRecordPaymentDialog = true },
            containerColor = StoreIndigo,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("record_payment_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Record Payment")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Record Payment", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showRecordPaymentDialog) {
        RecordPaymentBottomSheet(
            initialTimestamp = selectedCalendarTimestamp,
            onDismiss = { showRecordPaymentDialog = false },
            onSave = { itemDesc, totalAmt, method, date, notes ->
                viewModel.recordPayment(
                    customerId = 0L,
                    customerName = "Payment Entry",
                    saleId = null,
                    itemName = itemDesc,
                    totalAmount = totalAmt,
                    amountPaid = totalAmt,
                    remainingBalance = 0.0,
                    paymentMethod = method,
                    date = date,
                    notes = notes
                )
                showRecordPaymentDialog = false
            }
        )
    }
}

@Composable
fun PaymentEntryCard(payment: PaymentRecordEntity, currency: String) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("payment_entry_${payment.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = payment.itemName.ifEmpty { "Store Item Payment" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = dateFormat.format(Date(payment.date)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (payment.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = payment.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "+${formatCurrency(payment.amountPaid, currency)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = StoreEmerald
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (payment.paymentMethod.lowercase(Locale.ROOT)) {
                            "upi" -> StoreIndigo.copy(alpha = 0.12f)
                            "card" -> StoreGold.copy(alpha = 0.15f)
                            else -> StoreEmerald.copy(alpha = 0.12f)
                        }
                    ) {
                        Text(
                            text = payment.paymentMethod,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (payment.paymentMethod.lowercase(Locale.ROOT)) {
                                "upi" -> StoreIndigo
                                "card" -> StoreGold
                                else -> StoreEmerald
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Total Amount: ${formatCurrency(payment.totalAmount, currency)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Status: Received / Cleared",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = StoreEmerald
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentBottomSheet(
    initialTimestamp: Long,
    onDismiss: () -> Unit,
    onSave: (String, Double, String, Long, String) -> Unit
) {
    var itemDesc by remember { mutableStateOf("") }
    var totalAmountInput by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var notes by remember { mutableStateOf("") }
    var entryTimestamp by remember { mutableStateOf(initialTimestamp) }

    val quickItemSuggestions = listOf(
        "Cloth Purchase",
        "Men's Shirt",
        "Silk Saree",
        "Denim Jeans",
        "Trousers",
        "Kurti / Dress",
        "Suits / Blazer",
        "Tailoring Work",
        "Daily Collection"
    )

    val paymentMethods = listOf("Cash", "UPI", "Card", "Bank Transfer", "Cheque")

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Record Payment Entry",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Enter the item and total amount to directly credit into your payment book",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Item Name / Description Field
            OutlinedTextField(
                value = itemDesc,
                onValueChange = { itemDesc = it },
                label = { Text("Item / Description *") },
                placeholder = { Text("e.g., Silk Saree, Cotton Shirt, Daily Sale") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_item_desc_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Item Suggestion Chips
            Text("Quick Suggestions:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickItemSuggestions.forEach { suggestion ->
                    FilterChip(
                        selected = itemDesc == suggestion,
                        onClick = { itemDesc = suggestion },
                        label = { Text(suggestion, fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Total Amount Field (directly entries to total amount)
            OutlinedTextField(
                value = totalAmountInput,
                onValueChange = { totalAmountInput = it },
                label = { Text("Total Amount (₹) *") },
                placeholder = { Text("0.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_total_amount_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Payment Method Selection
            Text("Payment Method", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                paymentMethods.forEach { method ->
                    FilterChip(
                        selected = paymentMethod == method,
                        onClick = { paymentMethod = method },
                        label = { Text(method) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Optional Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Optional Notes / Transaction ID") },
                placeholder = { Text("e.g. UPI Ref #12345, Bill #52") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val amount = totalAmountInput.toDoubleOrNull() ?: 0.0
                    val finalItem = itemDesc.trim().ifEmpty { "Store Item Payment" }
                    if (amount > 0) {
                        onSave(
                            finalItem,
                            amount,
                            paymentMethod,
                            entryTimestamp,
                            notes.trim()
                        )
                    }
                },
                enabled = totalAmountInput.toDoubleOrNull() != null && (totalAmountInput.toDoubleOrNull() ?: 0.0) > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_payment_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo)
            ) {
                Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Payment (${totalAmountInput.ifEmpty { "0" }})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
