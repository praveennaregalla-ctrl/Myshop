package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.repository.CustomerWithLedger
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StoreSearchBar
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreEmeraldContainer
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreRose
import com.example.ui.theme.StoreRoseContainer
import com.example.viewmodel.StoreViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CustomerPurchasedItemDetail(
    val saleId: Long,
    val invoiceNumber: String,
    val productName: String,
    val size: String,
    val color: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double,
    val date: Long,
    val saleTotal: Double,
    val salePaid: Double,
    val saleRemaining: Double,
    val saleMethod: String,
    val rawSale: SaleEntity
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BalanceBookScreen(
    viewModel: StoreViewModel,
    onViewCustomerLedger: (CustomerWithLedger) -> Unit,
    modifier: Modifier = Modifier
) {
    val customerLedgers by viewModel.customerLedgers.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val saleItems by viewModel.saleItems.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("Pending Only") } // All Customers, Pending Only, Fully Paid, High Due (> ₹2000)

    var showAddCustomerSheet by remember { mutableStateOf(false) }
    var customerToCollectPayment by remember { mutableStateOf<CustomerWithLedger?>(null) }
    var customerToAddDue by remember { mutableStateOf<CustomerWithLedger?>(null) }
    var customerToMarkPaid by remember { mutableStateOf<CustomerWithLedger?>(null) }

    val totalPendingSum = customerLedgers.sumOf { it.remainingBalance }
    val totalPendingCount = customerLedgers.count { it.remainingBalance > 0 }
    val fullyPaidCount = customerLedgers.count { it.remainingBalance <= 0 }

    val filteredLedgers = customerLedgers.filter { ledger ->
        val matchesSearch = searchQuery.isEmpty() ||
                ledger.customer.name.contains(searchQuery, ignoreCase = true) ||
                ledger.customer.phoneNumber.contains(searchQuery)

        val matchesFilter = when (selectedFilter) {
            "Pending Only" -> ledger.remainingBalance > 0
            "Fully Paid" -> ledger.remainingBalance <= 0
            "High Due (> ₹2000)" -> ledger.remainingBalance >= 2000
            else -> true
        }

        matchesSearch && matchesFilter
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("balance_book_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Outstanding Debt Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = StoreRoseContainer),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Total Outstanding Pending Balance",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StoreRose
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = formatCurrency(totalPendingSum, currency),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = StoreRose
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(StoreRose),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = StoreRose.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Pending Accounts: $totalPendingCount customers",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = StoreRose
                            )
                            Text(
                                text = "Fully Cleared: $fullyPaidCount",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = StoreEmerald
                            )
                        }
                    }
                }
            }

            // Search Bar & Filter Chips
            item {
                Column {
                    StoreSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = "Search customer balance ledger..."
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val filterOptions = listOf("Pending Only", "All Customers", "High Due (> ₹2000)", "Fully Paid")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filterOptions.forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StoreIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            if (filteredLedgers.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No customer balance records found",
                        message = "Tap '+ Add Customer & Balance' below to add a customer and their pending balance details.",
                        icon = Icons.Default.CheckCircle,
                        actionLabel = "+ Add Customer & Balance",
                        onAction = { showAddCustomerSheet = true }
                    )
                }
            } else {
                items(filteredLedgers, key = { it.customer.id }) { ledger ->
                    val customerSales = remember(sales, ledger.customer.id) {
                        sales.filter { it.customerId == ledger.customer.id }
                    }
                    val customerSaleIds = remember(customerSales) {
                        customerSales.map { it.id }.toSet()
                    }
                    val customerItems = remember(saleItems, customerSales) {
                        val itemsMap = saleItems.filter { it.saleId in customerSaleIds }.groupBy { it.saleId }
                        val result = mutableListOf<CustomerPurchasedItemDetail>()
                        for (sale in customerSales) {
                            val matchedItems = itemsMap[sale.id]
                            if (!matchedItems.isNullOrEmpty()) {
                                for (it in matchedItems) {
                                    result.add(
                                        CustomerPurchasedItemDetail(
                                            saleId = sale.id,
                                            invoiceNumber = sale.invoiceNumber,
                                            productName = it.productName,
                                            size = it.size,
                                            color = it.color,
                                            quantity = it.quantity,
                                            unitPrice = it.unitPrice,
                                            totalPrice = it.totalPrice,
                                            date = sale.date,
                                            saleTotal = sale.totalAmount,
                                            salePaid = sale.amountPaid,
                                            saleRemaining = sale.remainingBalance,
                                            saleMethod = sale.paymentMethod,
                                            rawSale = sale
                                        )
                                    )
                                }
                            } else {
                                result.add(
                                    CustomerPurchasedItemDetail(
                                        saleId = sale.id,
                                        invoiceNumber = sale.invoiceNumber,
                                        productName = sale.notes.ifBlank { "Purchase #${sale.invoiceNumber}" },
                                        size = "-",
                                        color = "-",
                                        quantity = 1,
                                        unitPrice = sale.totalAmount,
                                        totalPrice = sale.totalAmount,
                                        date = sale.date,
                                        saleTotal = sale.totalAmount,
                                        salePaid = sale.amountPaid,
                                        saleRemaining = sale.remainingBalance,
                                        saleMethod = sale.paymentMethod,
                                        rawSale = sale
                                    )
                                )
                            }
                        }
                        result
                    }

                    BalanceLedgerCard(
                        ledger = ledger,
                        customerItems = customerItems,
                        currency = currency,
                        onCollectPayment = { customerToCollectPayment = ledger },
                        onAddDue = { customerToAddDue = ledger },
                        onMarkPaid = { customerToMarkPaid = ledger },
                        onViewDetails = { onViewCustomerLedger(ledger) },
                        onViewInvoice = { sale -> viewModel.showExistingInvoice(sale) }
                    )
                }
            }
        }

        // FAB to Add Customer & Balance Details
        FloatingActionButton(
            onClick = { showAddCustomerSheet = true },
            containerColor = StoreIndigo,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_customer_balance_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Customer & Balance")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Customer & Balance", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Add Customer & Balance Modal Bottom Sheet
    if (showAddCustomerSheet) {
        AddCustomerBalanceBottomSheet(
            onDismiss = { showAddCustomerSheet = false },
            onSave = { name, phone, address, openingBal, itemDesc, notes ->
                val newCustomer = CustomerEntity(
                    name = name,
                    phoneNumber = phone,
                    address = address,
                    notes = notes
                )
                viewModel.addCustomerWithBalance(
                    customer = newCustomer,
                    openingBalance = openingBal,
                    itemDescription = itemDesc
                )
                showAddCustomerSheet = false
            }
        )
    }

    // Collect Additional Payment Dialog
    customerToCollectPayment?.let { ledger ->
        CollectPaymentDialog(
            ledger = ledger,
            currency = currency,
            onDismiss = { customerToCollectPayment = null },
            onCollect = { amt, method, notes ->
                viewModel.recordPayment(
                    customerId = ledger.customer.id,
                    customerName = ledger.customer.name,
                    saleId = null,
                    itemName = "Balance Due Settlement",
                    totalAmount = ledger.remainingBalance,
                    amountPaid = amt,
                    remainingBalance = (ledger.remainingBalance - amt).coerceAtLeast(0.0),
                    paymentMethod = method,
                    notes = notes
                )
                customerToCollectPayment = null
            }
        )
    }

    // Add New Credit Due Amount Dialog for Existing Customer
    customerToAddDue?.let { ledger ->
        AddCustomerDueDialog(
            ledger = ledger,
            currency = currency,
            onDismiss = { customerToAddDue = null },
            onAddDue = { amt, desc, qty, unitPrice, notes ->
                viewModel.addCustomerDueAmount(
                    customerId = ledger.customer.id,
                    customerName = ledger.customer.name,
                    customerPhone = ledger.customer.phoneNumber,
                    amount = amt,
                    itemDescription = desc,
                    quantity = qty,
                    unitPrice = unitPrice,
                    notes = notes
                )
                customerToAddDue = null
            }
        )
    }

    // Mark Fully Paid Confirmation Dialog
    customerToMarkPaid?.let { ledger ->
        AlertDialog(
            onDismissRequest = { customerToMarkPaid = null },
            title = { Text("Mark Balance as Fully Paid?") },
            text = {
                Text("This will record a full payment of ${formatCurrency(ledger.remainingBalance, currency)} for customer '${ledger.customer.name}' and clear their outstanding ledger balance.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.recordPayment(
                            customerId = ledger.customer.id,
                            customerName = ledger.customer.name,
                            saleId = null,
                            itemName = "Full Outstanding Balance Clearance",
                            totalAmount = ledger.remainingBalance,
                            amountPaid = ledger.remainingBalance,
                            remainingBalance = 0.0,
                            paymentMethod = "Cash",
                            notes = "Auto-cleared in Balance Book"
                        )
                        customerToMarkPaid = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StoreEmerald)
                ) {
                    Text("Clear Full Balance")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToMarkPaid = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun BalanceLedgerCard(
    ledger: CustomerWithLedger,
    customerItems: List<CustomerPurchasedItemDetail>,
    currency: String,
    onCollectPayment: () -> Unit,
    onAddDue: () -> Unit,
    onMarkPaid: () -> Unit,
    onViewDetails: () -> Unit,
    onViewInvoice: (SaleEntity) -> Unit
) {
    var isItemsExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("balance_card_${ledger.customer.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Customer Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onViewDetails() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(StoreIndigo.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = StoreIndigo)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = ledger.customer.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = ledger.customer.phoneNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (ledger.remainingBalance <= 0) StoreEmeraldContainer else StoreRoseContainer
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (ledger.remainingBalance <= 0) "Paid / Clear" else "Pending Due",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (ledger.remainingBalance <= 0) StoreEmerald else StoreRose
                        )
                        Text(
                            text = formatCurrency(ledger.remainingBalance, currency),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (ledger.remainingBalance <= 0) StoreEmerald else StoreRose
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Purchase vs Paid Breakdown
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Purchases & Dues", style = MaterialTheme.typography.labelSmall)
                    Text(
                        formatCurrency(ledger.totalPurchaseAmount, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Total Paid", style = MaterialTheme.typography.labelSmall)
                    Text(
                        formatCurrency(ledger.totalAmountPaid, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = StoreEmerald
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Remaining Balance", style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = formatCurrency(ledger.remainingBalance, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (ledger.remainingBalance > 0) StoreRose else StoreEmerald
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // =========================================================================
            // Item Purchased Details with their Amounts Section
            // =========================================================================
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = StoreIndigo,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Purchased Items (${customerItems.size})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (customerItems.isNotEmpty()) {
                            Text(
                                text = "Amount",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(6.dp))

                    if (customerItems.isEmpty()) {
                        Text(
                            text = "No purchased items recorded yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        val displayedItems = if (isItemsExpanded) customerItems else customerItems.take(2)
                        val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

                        displayedItems.forEachIndexed { index, item ->
                            if (index > 0) {
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onViewInvoice(item.rawSale) }
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.productName,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    val attributesText = buildString {
                                        append("${item.quantity} pc")
                                        if (item.size != "-" && item.size.isNotBlank()) {
                                            append(" • Size: ${item.size}")
                                        }
                                        if (item.color != "-" && item.color.isNotBlank()) {
                                            append(" • ${item.color}")
                                        }
                                        append(" • #${item.invoiceNumber}")
                                    }
                                    Text(
                                        text = attributesText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = formatCurrency(item.totalPrice, currency),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StoreIndigo
                                    )
                                    if (item.quantity > 1) {
                                        Text(
                                            text = "@ ${formatCurrency(item.unitPrice, currency)}/ea",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Toggle Expand / Collapse button if more than 2 items
                        if (customerItems.size > 2) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isItemsExpanded = !isItemsExpanded }
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isItemsExpanded) "Show fewer items" else "View all ${customerItems.size} purchased items",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StoreIndigo,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = if (isItemsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = StoreIndigo,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onAddDue,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Add Due", style = MaterialTheme.typography.labelSmall)
                }

                if (ledger.remainingBalance > 0) {
                    OutlinedButton(
                        onClick = onMarkPaid,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StoreEmerald, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark Paid", style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = onCollectPayment,
                        colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo),
                        modifier = Modifier.weight(1.1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Collect", style = MaterialTheme.typography.labelSmall)
                    }
                } else {
                    Button(
                        onClick = onViewDetails,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ledger & Bills", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerBalanceBottomSheet(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var openingBalanceInput by remember { mutableStateOf("") }
    var itemDescription by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Add Customer & Balance Details",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Register customer into your Balance Book with their opening pending balance & item details",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Customer Full Name *") },
                placeholder = { Text("e.g. Ramesh Kumar") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_balance_cust_name"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number *") },
                placeholder = { Text("+91 98765 43210") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_balance_cust_phone"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = openingBalanceInput,
                onValueChange = { openingBalanceInput = it },
                label = { Text("Initial / Opening Pending Due (₹) *") },
                placeholder = { Text("0.00 (Enter initial pending amount)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_balance_cust_amount"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = itemDescription,
                onValueChange = { itemDescription = it },
                label = { Text("Purchased Item / Cloth Name") },
                placeholder = { Text("e.g. 2 Silk Sarees, Cotton Suit, or Opening Due") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address / City (Optional)") },
                placeholder = { Text("e.g. MG Road, Market Area") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Remarks / Previous Due Details (Optional)") },
                placeholder = { Text("e.g. Old ledger balance from last month") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val openingBal = openingBalanceInput.toDoubleOrNull() ?: 0.0
                    if (name.isNotBlank() && phone.isNotBlank()) {
                        onSave(
                            name.trim(),
                            phone.trim(),
                            address.trim(),
                            openingBal,
                            itemDescription.trim().ifBlank { "Opening Balance Due" },
                            notes.trim()
                        )
                    }
                },
                enabled = name.isNotBlank() && phone.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_customer_balance_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo)
            ) {
                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Customer to Balance Book", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AddCustomerDueDialog(
    ledger: CustomerWithLedger,
    currency: String,
    onDismiss: () -> Unit,
    onAddDue: (Double, String, Int, Double, String) -> Unit
) {
    var amountInput by remember { mutableStateOf("") }
    var itemDesc by remember { mutableStateOf("") }
    var qtyInput by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Due / Credit Bill for ${ledger.customer.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Current Due: ${formatCurrency(ledger.remainingBalance, currency)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = StoreRose,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = itemDesc,
                    onValueChange = { itemDesc = it },
                    label = { Text("Purchased Item / Cloth Name *") },
                    placeholder = { Text("e.g., 2 Silk Sarees, Linen Shirt") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = qtyInput,
                        onValueChange = { qtyInput = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Total Amount (₹) *") },
                        placeholder = { Text("0.00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(2f).testTag("add_due_amount_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Bill # (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull() ?: 0.0
                    val qty = qtyInput.toIntOrNull() ?: 1
                    val desc = itemDesc.trim().ifEmpty { "Credit Cloth Purchase" }
                    val unitPrice = if (qty > 0) amt / qty else amt
                    if (amt > 0) {
                        onAddDue(amt, desc, qty, unitPrice, notes.trim())
                    }
                },
                enabled = amountInput.toDoubleOrNull() != null && (amountInput.toDoubleOrNull() ?: 0.0) > 0,
                colors = ButtonDefaults.buttonColors(containerColor = StoreRose)
            ) {
                Text("Add to Balance")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CollectPaymentDialog(
    ledger: CustomerWithLedger,
    currency: String,
    onDismiss: () -> Unit,
    onCollect: (Double, String, String) -> Unit
) {
    var amountInput by remember { mutableStateOf(ledger.remainingBalance.toString()) }
    var selectedMethod by remember { mutableStateOf("Cash") }
    var notes by remember { mutableStateOf("") }

    val methods = listOf("Cash", "UPI", "Card", "Bank Transfer")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Collect Payment from ${ledger.customer.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Current Pending Due: ${formatCurrency(ledger.remainingBalance, currency)}",
                    style = MaterialTheme.typography.titleSmall,
                    color = StoreRose,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount Collecting Now *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("collect_amount_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Text("Payment Method", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    methods.forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method },
                            label = { Text(method) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Reference (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onCollect(amt, selectedMethod, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo)
            ) {
                Text("Record Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
