package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import android.net.Uri
import java.io.File
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.ProductEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ProductImageDisplay
import com.example.ui.components.StockBadge
import com.example.ui.components.StoreSearchBar
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreRose
import com.example.viewmodel.StoreViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    var productToEdit by remember { mutableStateOf<ProductEntity?>(null) }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var productToDelete by remember { mutableStateOf<ProductEntity?>(null) }

    val categories = listOf("All", "Formal Wear", "Casual Shirts", "Ethnic & Dresses", "Denim & Pants", "Outerwear")

    val filteredProducts = products.filter { product ->
        val matchesSearch = searchQuery.isEmpty() ||
                product.name.contains(searchQuery, ignoreCase = true) ||
                product.brand.contains(searchQuery, ignoreCase = true) ||
                product.color.contains(searchQuery, ignoreCase = true) ||
                product.supplierDetails.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategoryFilter == "All" || product.category.equals(selectedCategoryFilter, ignoreCase = true)
        val matchesLowStock = !filterLowStockOnly || product.quantity <= product.minStockThreshold

        matchesSearch && matchesCategory && matchesLowStock
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("inventory_screen_list"),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Controls & Filters
            item {
                Column {
                    StoreSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = "Search clothes, brand, supplier..."
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = filterLowStockOnly,
                            onClick = { filterLowStockOnly = !filterLowStockOnly },
                            label = { Text("⚠️ Low Stock Only") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StoreRose,
                                selectedLabelColor = Color.White
                            )
                        )

                        categories.forEach { category ->
                            FilterChip(
                                selected = selectedCategoryFilter == category,
                                onClick = { selectedCategoryFilter = category },
                                label = { Text(category) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StoreIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${filteredProducts.size} Items listed • Total Stock: ${filteredProducts.sumOf { it.quantity }} pcs",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (filteredProducts.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No clothes in inventory",
                        message = "Tap the + button below to add your first clothing item to stock.",
                        icon = Icons.Outlined.Inventory2
                    )
                }
            } else {
                items(filteredProducts, key = { it.id }) { product ->
                    InventoryItemCard(
                        product = product,
                        currency = currency,
                        onEdit = {
                            productToEdit = product
                            showAddEditDialog = true
                        },
                        onDelete = {
                            productToDelete = product
                        }
                    )
                }
            }
        }

        // Floating Action Button to Add New Item
        FloatingActionButton(
            onClick = {
                productToEdit = null
                showAddEditDialog = true
            },
            containerColor = StoreIndigo,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_product_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Item")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Clothes", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Add / Edit Product Sheet
    if (showAddEditDialog) {
        AddEditProductBottomSheet(
            product = productToEdit,
            onDismiss = {
                showAddEditDialog = false
                productToEdit = null
            },
            onSave = { updatedProduct ->
                if (productToEdit == null) {
                    viewModel.addProduct(updatedProduct)
                } else {
                    viewModel.updateProduct(updatedProduct)
                }
                showAddEditDialog = false
                productToEdit = null
            }
        )
    }

    // Delete Confirmation Dialog
    productToDelete?.let { product ->
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("Delete Clothing Item?") },
            text = { Text("Are you sure you want to delete '${product.name}' from your store inventory? This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteProduct(product)
                        productToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StoreRose)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun InventoryItemCard(
    product: ProductEntity,
    currency: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("inventory_item_${product.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProductImageDisplay(
                    drawableName = product.imageDrawableName,
                    imageUri = product.imageUri,
                    contentDescription = product.name,
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(10.dp))
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = product.brand,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = product.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        StockBadge(
                            quantity = product.quantity,
                            minThreshold = product.minStockThreshold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "Size: ${product.size}",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = product.color,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = product.category,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(8.dp))

            // Pricing & Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column {
                            Text(
                                text = "Selling Price",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formatCurrency(product.sellingPrice, currency),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = StoreIndigo
                            )
                        }
                        Column {
                            Text(
                                text = "Purchase Cost",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formatCurrency(product.purchasePrice, currency),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onEdit) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = StoreRose)
                    }
                }
            }

            if (product.supplierDetails.isNotEmpty()) {
                Text(
                    text = "Supplier: ${product.supplierDetails}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun saveImageToInternalStorage(context: Context, uri: Uri): String? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val timeStamp = System.currentTimeMillis()
        val file = File(context.filesDir, "cloth_product_${timeStamp}.jpg")
        file.outputStream().use { out ->
            inputStream.copyTo(out)
        }
        file.absolutePath
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductBottomSheet(
    product: ProductEntity?,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(product?.name ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Formal Wear") }
    var brand by remember { mutableStateOf(product?.brand ?: "") }
    var size by remember { mutableStateOf(product?.size ?: "L") }
    var color by remember { mutableStateOf(product?.color ?: "") }
    var purchasePriceInput by remember { mutableStateOf(product?.purchasePrice?.toString() ?: "") }
    var sellingPriceInput by remember { mutableStateOf(product?.sellingPrice?.toString() ?: "") }
    var quantityInput by remember { mutableStateOf(product?.quantity?.toString() ?: "10") }
    var minStockInput by remember { mutableStateOf(product?.minStockThreshold?.toString() ?: "5") }
    var supplierDetails by remember { mutableStateOf(product?.supplierDetails ?: "") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var isNewArrival by remember { mutableStateOf(product?.isNewArrival ?: true) }
    
    var imageUri by remember { mutableStateOf(product?.imageUri ?: "") }
    var imageDrawableName by remember { mutableStateOf(product?.imageDrawableName ?: "cloth_shirt_1788199086938") }
    var showUrlDialog by remember { mutableStateOf(false) }
    var customUrlInput by remember { mutableStateOf(if (imageUri.startsWith("http")) imageUri else "") }

    // Photo Pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val saved = saveImageToInternalStorage(context, uri)
            if (saved != null) {
                imageUri = saved
                imageDrawableName = ""
            }
        }
    }

    val filePickerFallback = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val saved = saveImageToInternalStorage(context, uri)
            if (saved != null) {
                imageUri = saved
                imageDrawableName = ""
            }
        }
    }

    val imagePresets = listOf(
        "cloth_suit_1788199060322" to "Suit",
        "cloth_dress_1788199073586" to "Dress/Gown",
        "cloth_shirt_1788199086938" to "Shirt",
        "cloth_jacket_1788199103681" to "Jacket",
        "cloth_jeans_1788199117720" to "Jeans"
    )

    val categories = listOf("Formal Wear", "Casual Shirts", "Ethnic & Dresses", "Denim & Pants", "Outerwear", "Accessories")
    val sizes = listOf("S", "M", "L", "XL", "XXL", "30", "32", "34", "36")

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (product == null) "Add New Clothes" else "Edit Clothing Item",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hero Product Image Preview Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    ProductImageDisplay(
                        drawableName = imageDrawableName,
                        imageUri = imageUri,
                        contentDescription = name.ifEmpty { "Product Image Preview" },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Image Source Tag Indicator
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.65f)
                    ) {
                        val sourceLabel = when {
                            imageUri.startsWith("/") || imageUri.startsWith("file:") -> "📸 Device Photo"
                            imageUri.startsWith("http") -> "🌐 Web Image"
                            imageDrawableName.isNotEmpty() -> "🎨 Style Preset"
                            else -> "No Image Selected"
                        }
                        Text(
                            text = sourceLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (imageUri.isNotEmpty() || imageDrawableName.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                imageUri = ""
                                imageDrawableName = ""
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                                .size(32.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear Image",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons to Add Image from Device or Web URL
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        try {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        } catch (e: Exception) {
                            filePickerFallback.launch("image/*")
                        }
                    },
                    modifier = Modifier.weight(1.3f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Add Photo",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Upload Photo", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { showUrlDialog = !showUrlDialog },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Image Link",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Paste URL", fontSize = 13.sp)
                }
            }

            // Expandable Image URL Input field
            AnimatedVisibility(visible = showUrlDialog) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    OutlinedTextField(
                        value = customUrlInput,
                        onValueChange = {
                            customUrlInput = it
                            if (it.isNotBlank()) {
                                imageUri = it.trim()
                                imageDrawableName = ""
                            }
                        },
                        label = { Text("Image Web URL (HTTPS)") },
                        placeholder = { Text("https://images.unsplash.com/photo-...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        trailingIcon = {
                            if (customUrlInput.isNotEmpty()) {
                                IconButton(onClick = {
                                    customUrlInput = ""
                                    imageUri = ""
                                }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Preset Selection
            Text(
                text = "Or Pick a Style Preset",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                imagePresets.forEach { (imgName, label) ->
                    val isSelected = imageDrawableName == imgName && imageUri.isEmpty()
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) StoreIndigo.copy(alpha = 0.12f) else Color.Transparent)
                            .clickable {
                                imageDrawableName = imgName
                                imageUri = ""
                                customUrlInput = ""
                            }
                            .padding(4.dp)
                    ) {
                        ProductImageDisplay(
                            drawableName = imgName,
                            contentDescription = label,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) StoreIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Item Name *") },
                placeholder = { Text("e.g. Italian Wool Suit, Cotton Check Shirt") },
                modifier = Modifier.fillMaxWidth().testTag("product_name_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Brand *") },
                    placeholder = { Text("Raymond, Zara, etc.") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it },
                    label = { Text("Color *") },
                    placeholder = { Text("Navy Blue, Black...") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Chips
            Text(text = "Category", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Size Chips
            Text(text = "Size", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sizes.forEach { sz ->
                    FilterChip(
                        selected = size == sz,
                        onClick = { size = sz },
                        label = { Text(sz, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Prices
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = purchasePriceInput,
                    onValueChange = { purchasePriceInput = it },
                    label = { Text("Purchase Price *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = sellingPriceInput,
                    onValueChange = { sellingPriceInput = it },
                    label = { Text("Selling Price *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stock Quantities
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = quantityInput,
                    onValueChange = { quantityInput = it },
                    label = { Text("Stock Quantity *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = minStockInput,
                    onValueChange = { minStockInput = it },
                    label = { Text("Low Stock Alert Qty") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = supplierDetails,
                onValueChange = { supplierDetails = it },
                label = { Text("Supplier Details") },
                placeholder = { Text("e.g. Milano Fabrics, Surat Textiles") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description / Fabric specs") },
                placeholder = { Text("100% cotton, wrinkle free, slim fit...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))

            // New Arrival Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Feature in 'New Arrivals' Section",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Switch(checked = isNewArrival, onCheckedChange = { isNewArrival = it })
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    val pPrice = purchasePriceInput.toDoubleOrNull() ?: 0.0
                    val sPrice = sellingPriceInput.toDoubleOrNull() ?: 0.0
                    val qty = quantityInput.toIntOrNull() ?: 0
                    val minThreshold = minStockInput.toIntOrNull() ?: 5

                    val result = product?.copy(
                        name = name.trim(),
                        category = category,
                        brand = brand.trim().ifEmpty { "Generic" },
                        size = size,
                        color = color.trim().ifEmpty { "Standard" },
                        purchasePrice = pPrice,
                        sellingPrice = sPrice,
                        quantity = qty,
                        minStockThreshold = minThreshold,
                        supplierDetails = supplierDetails.trim(),
                        description = description.trim(),
                        isNewArrival = isNewArrival,
                        imageDrawableName = imageDrawableName,
                        imageUri = imageUri
                    ) ?: ProductEntity(
                        name = name.trim(),
                        category = category,
                        brand = brand.trim().ifEmpty { "Generic" },
                        size = size,
                        color = color.trim().ifEmpty { "Standard" },
                        purchasePrice = pPrice,
                        sellingPrice = sPrice,
                        quantity = qty,
                        minStockThreshold = minThreshold,
                        supplierDetails = supplierDetails.trim(),
                        description = description.trim(),
                        isNewArrival = isNewArrival,
                        imageDrawableName = imageDrawableName,
                        imageUri = imageUri
                    )

                    onSave(result)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_product_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = StoreIndigo)
            ) {
                Text("Save Clothing Item", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
