package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entities.CustomerEntity
import com.example.data.local.entities.SaleEntity
import com.example.data.repository.CustomerWithLedger
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StoreSearchBar
import com.example.ui.components.formatCurrency
import com.example.ui.theme.StoreEmerald
import com.example.ui.theme.StoreGold
import com.example.ui.theme.StoreIndigo
import com.example.ui.theme.StoreRose
import com.example.viewmodel.StoreViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    viewModel: StoreViewModel,
    onViewSaleInvoice: (SaleEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val customerLedgers by viewModel.customerLedgers.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currency = settings?.currencySymbol ?: "₹"

    var searchQuery by remember { mutableStateOf("") }
    var selectedCustomerForDetails by remember { mutableStateOf<CustomerWithLedger?>(null) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }

    val filteredLedgers = customerLedgers.filter {
        searchQuery.isEmpty() ||
                it.customer.name.contains(searchQuery, ignoreCase = true) ||
                it.customer.phoneNumber.contains(searchQuery) ||
                it.customer.address.contains(searchQuery, ignoreCase = true)
    }

    Box(modifier = modifier.fillMaxSize().testTag("customers_screen")) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                StoreSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Search customers by name or phone..."
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${filteredLedgers.size} Customers Registered",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val totalPending = filteredLedgers.sumOf { it.remainingBalance }
                    if (totalPending > 0) {
                        Text(
                            text = "Total Pending: ${formatCurrency(totalPending, currency)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StoreRose
                        )
                    }
                }
            }

            if (filteredLedgers.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No customers found",
                        message = "Tap the + button to register your first customer.",
                        icon = Icons.Default.People
                    )
                }
            } else {
                items(filteredLedgers, key = { it.customer.id }) { ledger ->
                    CustomerCard(
                        ledger = ledger,
                        currency = currency,
                        onClick = { selectedCustomerForDetails = ledger }
                    )
                }
            }
        }

        // FAB to add customer
        FloatingActionButton(
            onClick = { showAddCustomerDialog = true },
            containerColor = StoreIndigo,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_customer_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Customer")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Customer", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onSave = { newCust ->
                viewModel.addCustomer(newCust)
                showAddCustomerDialog = false
            }
        )
    }

    selectedCustomerForDetails?.let { ledger ->
        CustomerDetailBottomSheet(
            ledger = ledger,
            viewModel = viewModel,
            currency = currency,
            onDismiss = { selectedCustomerForDetails = null },
            onViewInvoice = onViewSaleInvoice
        )
    }
}

@Composable
fun CustomerCard(
    ledger: CustomerWithLedger,
    currency: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("customer_card_${ledger.customer.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(StoreIndigo.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = StoreIndigo)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = ledger.customer.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = ledger.customer.phoneNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (ledger.remainingBalance <= 0) StoreEmerald.copy(alpha = 0.12f) else StoreRose.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = if (ledger.remainingBalance <= 0) "Clear" else "Due ${formatCurrency(ledger.remainingBalance, currency)}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (ledger.remainingBalance <= 0) StoreEmerald else StoreRose,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Purchases",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(ledger.totalPurchaseAmount, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Total Paid",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(ledger.totalAmountPaid, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = StoreEmerald
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Balance",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(ledger.remainingBalance, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (ledger.remainingBalance > 0) StoreRose else StoreEmerald
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailBottomSheet(
    ledger: CustomerWithLedger,
    viewModel: StoreViewModel,
    currency: String,
    onDismiss: () -> Unit,
    onViewInvoice: (SaleEntity) -> Unit
) {
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val saleItems by viewModel.saleItems.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()

    val customerSales = sales.filter { it.customerId == ledger.customer.id }
    val customerPayments = payments.filter { it.customerId == ledger.customer.id }

    var historyTab by remember { mutableIntStateOf(0) } // 0: Purchases, 1: Payments

    ModalBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Customer Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = ledger.customer.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(text = ledger.customer.phoneNumber, style = MaterialTheme.typography.bodyMedium, color = StoreIndigo)
                    if (ledger.customer.address.isNotEmpty()) {
                        Text(text = ledger.customer.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (ledger.remainingBalance <= 0) StoreEmerald.copy(alpha = 0.15f) else StoreRose.copy(alpha = 0.15f)
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(text = "Remaining Balance", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = formatCurrency(ledger.remainingBalance, currency),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (ledger.remainingBalance <= 0) StoreEmerald else StoreRose
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Stats Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "Total Spent", style = MaterialTheme.typography.labelSmall)
                        Text(text = formatCurrency(ledger.totalPurchaseAmount, currency), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "Total Paid", style = MaterialTheme.typography.labelSmall)
                        Text(text = formatCurrency(ledger.totalAmountPaid, currency), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StoreEmerald)
                    }
                    Column {
                        Text(text = "Orders", style = MaterialTheme.typography.labelSmall)
                        Text(text = "${ledger.salesCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tabs for Purchases & Payments
            TabRow(selectedTabIndex = historyTab) {
                Tab(
                    selected = historyTab == 0,
                    onClick = { historyTab = 0 },
                    text = { Text("Purchases (${customerSales.size})") }
                )
                Tab(
                    selected = historyTab == 1,
                    onClick = { historyTab = 1 },
                    text = { Text("Payments (${customerPayments.size})") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (historyTab == 0) {
                // Purchases History
                if (customerSales.isEmpty()) {
                    Text(
                        text = "No purchase records found for this customer.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    customerSales.forEach { sale ->
                        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                        val itemsForThisSale = saleItems.filter { it.saleId == sale.id }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = sale.invoiceNumber, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = dateFormat.format(Date(sale.date)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = formatCurrency(sale.totalAmount, currency),
                                            fontWeight = FontWeight.Bold,
                                            color = StoreIndigo
                                        )
                                        Text(
                                            text = if (sale.remainingBalance <= 0) "Paid" else "Due: ${formatCurrency(sale.remainingBalance, currency)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (sale.remainingBalance <= 0) StoreEmerald else StoreRose,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                if (itemsForThisSale.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "Purchased Items:",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    itemsForThisSale.forEach { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${item.quantity}x ${item.productName}",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                if (item.size != "-" || item.color != "-") {
                                                    Text(
                                                        text = "Size: ${item.size} • Color: ${item.color}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Text(
                                                text = formatCurrency(item.totalPrice, currency),
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = StoreIndigo
                                            )
                                        }
                                    }
                                } else if (sale.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Item/Details: ${sale.notes}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            onDismiss()
                                            onViewInvoice(sale)
                                        }
                                    ) {
                                        Text("View / Print Bill", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Payments History
                if (customerPayments.isEmpty()) {
                    Text(
                        text = "No payment records found for this customer.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    customerPayments.forEach { pay ->
                        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = pay.itemName, fontWeight = FontWeight.SemiBold)
                                    Text(text = "${dateFormat.format(Date(pay.date))} • ${pay.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "+${formatCurrency(pay.amountPaid, currency)}", fontWeight = FontWeight.Bold, color = StoreEmerald)
                                    if (pay.remainingBalance > 0) {
                                        Text(text = "Remaining: ${formatCurrency(pay.remainingBalance, currency)}", style = MaterialTheme.typography.labelSmall, color = StoreRose)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
