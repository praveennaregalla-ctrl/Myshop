package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Indigo / Sapphire Primary
val StoreIndigoDark = Color(0xFF0F172A)
val StoreIndigo = Color(0xFF1E3A8A)
val StoreIndigoLight = Color(0xFF3B82F6)
val StoreIndigoContainer = Color(0xFFDBEAFE)
val StoreOnIndigoContainer = Color(0xFF1E40AF)

// Amber / Gold Secondary (Luxury accent)
val StoreGold = Color(0xFFD97706)
val StoreGoldLight = Color(0xFFFBBF24)
val StoreGoldContainer = Color(0xFFFEF3C7)
val StoreOnGoldContainer = Color(0xFF92400E)

// Emerald / Teal Success
val StoreEmerald = Color(0xFF059669)
val StoreEmeraldContainer = Color(0xFFD1FAE5)

// Rose / Crimson Alert (Low stock, High balance)
val StoreRose = Color(0xFFE11D48)
val StoreRoseContainer = Color(0xFFFFE4E6)

// Neutrals
val StoreSurfaceLight = Color(0xFFF8FAFC)
val StoreSurfaceCardLight = Color(0xFFFFFFFF)
val StoreBorderLight = Color(0xFFE2E8F0)
val StoreTextPrimary = Color(0xFF0F172A)
val StoreTextSecondary = Color(0xFF64748B)

// Dark Palette
val StoreSurfaceDark = Color(0xFF0B0F19)
val StoreSurfaceCardDark = Color(0xFF161F30)
val StoreBorderDark = Color(0xFF26334D)
val StoreTextPrimaryDark = Color(0xFFF8FAFC)
val StoreTextSecondaryDark = Color(0xFF94A3B8)

