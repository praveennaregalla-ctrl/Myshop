package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("S V FASHION DAMBAL", appName)
  }

  @Test
  fun `ledger balance calculation test`() {
    val totalPurchases = 4500.0
    val totalPaid = 3000.0
    val remainingBalance = (totalPurchases - totalPaid).coerceAtLeast(0.0)
    assertEquals(1500.0, remainingBalance, 0.001)
  }
}

